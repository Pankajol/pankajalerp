import { NextResponse } from "next/server";
import mongoose from "mongoose";
import bcrypt from "bcryptjs";
import dbConnect from "@/lib/db";
import Student from "@/models/school/Student";
import House from "@/models/school/House";
import CompanyUser from "@/models/CompanyUser";
import { getTokenFromHeader, verifyJWT } from "@/lib/auth";

// ─── Auth helpers ────────────────────────────────────────────────────
function isAuthorized(user) {
  if (!user) return false;
  if (user.type === "company") return true;
  const allowedRoles = [
    "admin",
    "school admin",
    "principal",
    "teacher",
    "student",
    "parent",
  ];
  const userRoles = Array.isArray(user.roles) ? user.roles : [];
  return userRoles.some((role) => allowedRoles.includes(role.trim().toLowerCase()));
}

async function validateUser(req) {
  const token = getTokenFromHeader(req);
  if (!token) return { error: "Token missing", status: 401 };
  try {
    const user = await verifyJWT(token);
    if (!user || !isAuthorized(user)) return { error: "Unauthorized", status: 403 };
    return { user };
  } catch {
    return { error: "Invalid token", status: 401 };
  }
}

function isPortalStudentOrParent(user) {
  return user?.type === "school" && ["student", "parent"].includes(user.schoolRole || user.role);
}

function isPortalUser(user) {
  return user?.type === "school";
}


// ─── GET (single) ────────────────────────────────────────────────────
export async function GET(req, { params }) {
  await dbConnect();
  const { user, error, status } = await validateUser(req);
  if (error) return NextResponse.json({ success: false, message: error }, { status });

  try {
    const { id } = await params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return NextResponse.json({ success: false, message: "Invalid ID" }, { status: 400 });
    }
    if (isPortalStudentOrParent(user) && String(user.id) !== String(id)) {
      return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 403 });
    }

    const student = await Student.findOne({ _id: id, companyId: user.companyId })
      .populate("house", "name color motto captain viceCaptain")
      .populate("siblings", "firstName lastName studentId class")
      .populate("createdBy", "name")
      .lean();

    if (!student) {
      return NextResponse.json({ success: false, message: "Student not found" }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: student });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
  }
}

// ─── PUT (update) ────────────────────────────────────────────────────
export async function PUT(req, { params }) {
  await dbConnect();
  const { user, error, status } = await validateUser(req);
  if (error) return NextResponse.json({ success: false, message: error }, { status });

  try {
    if (isPortalUser(user)) {
      return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 403 });
    }

    const { id } = await params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return NextResponse.json({ success: false, message: "Invalid ID" }, { status: 400 });
    }

    const body = await req.json();

    const student = await Student.findOne({ _id: id, companyId: user.companyId });
    if (!student) {
      return NextResponse.json({ success: false, message: "Student not found" }, { status: 404 });
    }

    // Validate house if provided
    if (body.house) {
      const houseDoc = await House.findOne({
        _id: body.house,
        companyId: user.companyId,
      });
      if (!houseDoc) {
        return NextResponse.json(
          { success: false, message: "House not found" },
          { status: 400 }
        );
      }
    }

    // Allowed fields to update
    const updatable = [
      "firstName",
      "lastName",
      "dateOfBirth",
      "gender",
      "email",
      "phone",
      "address",
      "class",
      "section",
      "rollNumber",
      "house",
      "isActive",
      "isScholar",
      "multiClasses",
      "parent",
      "siblings",
    ];

    for (const field of updatable) {
      if (body[field] !== undefined) {
        student[field] = body[field];
      }
    }
    const credentialUpdate = {};
    if (body.password) {
      student.passwordHash = await bcrypt.hash(body.password, 10);
      credentialUpdate.passwordHash = student.passwordHash;
    }
    if (body.parentPassword) {
      student.parentPasswordHash = await bcrypt.hash(body.parentPassword, 10);
      credentialUpdate.parentPasswordHash = student.parentPasswordHash;
    }

    await student.save();
    if (Object.keys(credentialUpdate).length) {
      await Student.updateOne({ _id: student._id }, { $set: credentialUpdate }, { strict: false });
    }
    await student.populate("house", "name color");
    const studentResponse = student.toObject();
    delete studentResponse.passwordHash;
    delete studentResponse.parentPasswordHash;

    return NextResponse.json({
      success: true,
      data: studentResponse,
      message: "Student updated successfully",
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { success: false, message: err.message || "Update failed" },
      { status: 500 }
    );
  }
}

// ─── DELETE (soft delete) ───────────────────────────────────────────
export async function DELETE(req, { params }) {
  await dbConnect();
  const { user, error, status } = await validateUser(req);
  if (error) return NextResponse.json({ success: false, message: error }, { status });

  try {
    if (isPortalUser(user)) {
      return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 403 });
    }

    const { id } = await params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return NextResponse.json({ success: false, message: "Invalid ID" }, { status: 400 });
    }

    // Soft delete – set isActive = false
    const student = await Student.findOneAndUpdate(
      { _id: id, companyId: user.companyId },
      { isActive: false },
      { new: true }
    );

    if (!student) {
      return NextResponse.json({ success: false, message: "Student not found" }, { status: 404 });
    }

    return NextResponse.json({
      success: true,
      message: "Student disabled successfully",
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { success: false, message: err.message || "Delete failed" },
      { status: 500 }
    );
  }
}

// ─── Enable Student ──────────────────────────────────────────────────
export async function PATCH(req, { params }) {
  await dbConnect();
  const { user, error, status } = await validateUser(req);
  if (error) return NextResponse.json({ success: false, message: error }, { status });

  try {
    if (isPortalUser(user)) {
      return NextResponse.json({ success: false, message: "Unauthorized" }, { status: 403 });
    }

    const { id } = await params;
    const { action } = await req.json();

    if (action === "enable") {
      const student = await Student.findOneAndUpdate(
        { _id: id, companyId: user.companyId },
        { isActive: true },
        { new: true }
      );
      if (!student) {
        return NextResponse.json({ success: false, message: "Student not found" }, { status: 404 });
      }
      return NextResponse.json({ success: true, data: student, message: "Student enabled" });
    }

    return NextResponse.json({ success: false, message: "Invalid action" }, { status: 400 });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
  }
}
