// src/app/api/items/[id]/route.js

import { NextResponse } from 'next/server';
import connectDB from '@/lib/db';
import Item from '@/models/ItemModels';
import { getTokenFromHeader, verifyJWT } from '@/lib/auth';

export async function GET(req, { params }) {
  try {
    await connectDB();

    // Authenticate
    const token = getTokenFromHeader(req);
    if (!token) {
      return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 });
    }
    const user = verifyJWT(token);
    if (!user || !user.companyId) {
      return NextResponse.json({ success: false, message: 'Invalid token' }, { status: 401 });
    }

    // ✅ FIX: Await params before using it
    const { id } = await params;

    if (!id) {
      return NextResponse.json({ success: false, message: 'Item ID is required' }, { status: 400 });
    }

    const item = await Item.findOne({ _id: id, companyId: user.companyId });
    if (!item) {
      return NextResponse.json({ success: false, message: 'Item not found' }, { status: 404 });
    }

    return NextResponse.json({ success: true, data: item }, { status: 200 });
  } catch (error) {
    console.error('GET /api/items/[id] error:', error);
    return NextResponse.json(
      { success: false, message: error.message || 'Server error' },
      { status: 500 }
    );
  }
}

// Also fix other methods (PUT, DELETE, etc.) if they use params
export async function PUT(req, { params }) {
  try {
    await connectDB();
    const token = getTokenFromHeader(req);
    if (!token) return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 });
    const user = verifyJWT(token);
    if (!user || !user.companyId) {
      return NextResponse.json({ success: false, message: 'Invalid token' }, { status: 401 });
    }

    const { id } = await params; // ✅ await here too
    const body = await req.json();

    const updated = await Item.findOneAndUpdate(
      { _id: id, companyId: user.companyId },
      body,
      { new: true }
    );
    if (!updated) {
      return NextResponse.json({ success: false, message: 'Item not found' }, { status: 404 });
    }
    return NextResponse.json({ success: true, data: updated }, { status: 200 });
  } catch (error) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}

export async function DELETE(req, { params }) {
  try {
    await connectDB();
    const token = getTokenFromHeader(req);
    if (!token) return NextResponse.json({ success: false, message: 'Unauthorized' }, { status: 401 });
    const user = verifyJWT(token);
    if (!user || !user.companyId) {
      return NextResponse.json({ success: false, message: 'Invalid token' }, { status: 401 });
    }

    const { id } = await params; // ✅ await here too
    const deleted = await Item.findOneAndDelete({ _id: id, companyId: user.companyId });
    if (!deleted) {
      return NextResponse.json({ success: false, message: 'Item not found' }, { status: 404 });
    }
    return NextResponse.json({ success: true, message: 'Item deleted' }, { status: 200 });
  } catch (error) {
    return NextResponse.json({ success: false, message: error.message }, { status: 500 });
  }
}