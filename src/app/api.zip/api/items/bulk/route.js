import { NextResponse } from "next/server";
import dbConnect from "@/lib/db";
import Item from "@/models/ItemModels";
import { getTokenFromHeader, verifyJWT } from "@/lib/auth";

// ── Auth helpers ──
function isAuthorized(user) {
  if (!user) return false;
  if (user.type === "company") return true;
  const allowedRoles = [
    "admin", "sales manager", "purchase manager", "inventory manager",
    "accounts manager", "hr manager", "support executive",
    "production head", "project manager",
  ];
  const userRoles = Array.isArray(user.roles) ? user.roles : [];
  return userRoles.some(role => allowedRoles.includes(role.trim().toLowerCase()));
}

async function validateUser(req) {
  const token = getTokenFromHeader(req);
  if (!token) return { error: "Token missing", status: 401 };
  try {
    const user = await verifyJWT(token);
    if (!user || !isAuthorized(user)) return { error: "Unauthorized", status: 403 };
    return { user };
  } catch {
    return { error: "Invalid token", status: 401 };
  }
}

// ── Type normalisation helpers ──
function toBoolean(value) {
  if (typeof value === "boolean") return value;
  if (typeof value === "string") {
    const lower = value.trim().toLowerCase();
    return lower === "true" || lower === "1" || lower === "yes";
  }
  return !!value;
}

function toNumber(value) {
  if (value === null || value === undefined || value === "") return null;
  const num = parseFloat(value);
  return isNaN(num) ? null : num;
}

function toInt(value) {
  if (value === null || value === undefined || value === "") return null;
  const num = parseInt(value, 10);
  return isNaN(num) ? null : num;
}

function toDate(value) {
  if (!value) return null;
  const d = new Date(value);
  return isNaN(d.getTime()) ? null : d;
}

// ── Parse variants from CSV ──
function parseVariants(variantsInput) {
  if (!variantsInput) return [];
  if (Array.isArray(variantsInput)) return variantsInput;
  if (typeof variantsInput === "string") {
    try {
      const parsed = JSON.parse(variantsInput);
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
  return [];
}

// ── POST handler ──
export async function POST(req) {
  await dbConnect();

  const { user, error, status } = await validateUser(req);
  if (error) {
    return NextResponse.json({ success: false, message: error }, { status });
  }

  try {
    const { items } = await req.json();
    if (!Array.isArray(items) || items.length === 0) {
      return NextResponse.json(
        { success: false, message: "Invalid or empty items array" },
        { status: 400 }
      );
    }

    // ── Get the latest item code for this company ──
    const lastItem = await Item.findOne({ companyId: user.companyId })
      .sort({ itemCode: -1 })
      .lean();

    let nextNumber = 1;
    if (lastItem && lastItem.itemCode) {
      const match = lastItem.itemCode.match(/ITEM-(\d+)/);
      if (match) {
        nextNumber = parseInt(match[1], 10) + 1;
      }
    }

    const results = [];
    let createdCount = 0,
        updatedCount = 0,
        skippedCount = 0;

    let currentNumber = nextNumber;

    for (let i = 0; i < items.length; i++) {
      const row = items[i];
      const errors = [];

      // ── Basic validation ──
      if (!row.itemName) errors.push("itemName is required");
      if (!row.category) errors.push("category is required");
      if (row.unitPrice === undefined || row.unitPrice === null) {
        errors.push("unitPrice is required");
      } else {
        const unitPriceNum = toNumber(row.unitPrice);
        if (unitPriceNum === null) errors.push("unitPrice must be a number");
      }
      if (row.gstRate && toNumber(row.gstRate) === null) {
        errors.push("gstRate must be a number");
      }
      if (row.status && !["active", "inactive"].includes(row.status.toLowerCase())) {
        errors.push("status must be 'active' or 'inactive'");
      }
      if (row.itemCode && typeof row.itemCode !== "string") {
        errors.push("itemCode must be a string");
      }

      // ── Parse variants ──
      let parsedVariants = [];
      if (row.variants) {
        parsedVariants = parseVariants(row.variants);
        if (typeof row.variants === "string" && parsedVariants.length === 0) {
          errors.push("variants could not be parsed; must be a valid JSON array");
        }
      }

      const normalizedVariants = parsedVariants.map((v, idx) => {
        let attrs = v.attributes || {};
        if (typeof attrs === "string") {
          try { attrs = JSON.parse(attrs); } catch { attrs = {}; }
        }
        return {
          sku: v.sku || `V-${idx+1}`,
          attributes: attrs,
          price: toNumber(v.price),
          quantity: toInt(v.quantity) || 0,
          imageUrl: v.imageUrl || "",
          barcode: v.barcode || "",
          posPrice: toNumber(v.posPrice),
        };
      });

      if (errors.length > 0) {
        skippedCount++;
        results.push({ row: i + 1, success: false, errors });
        continue;
      }

      // ── Find existing item ──
      let existingItem = null;
      if (row.itemCode) {
        existingItem = await Item.findOne({ companyId: user.companyId, itemCode: row.itemCode });
      }
      if (!existingItem) {
        existingItem = await Item.findOne({
          companyId: user.companyId,
          itemName: { $regex: new RegExp(`^${row.itemName}$`, "i") },
        });
      }

      // ── Build item data with proper type conversions ──
      const itemData = {
        companyId: user.companyId,
        createdBy: user.id,
        itemName: row.itemName?.trim() || "",
        category: row.category?.trim() || "",
        unitPrice: toNumber(row.unitPrice) || 0,
        description: row.description || "",
        hsnCode: row.hsnCode || "",
        gstRate: toNumber(row.gstRate) || 0,
        unit: row.unit || "piece",
        uom: row.uom || "",
        quantity: toInt(row.quantity) || 0,
        stockQuantity: toInt(row.stockQuantity) || 0,
        inStock: row.inStock !== undefined ? toBoolean(row.inStock) : true,
        reorderLevel: toInt(row.reorderLevel) || 0,
        leadTime: toInt(row.leadTime) || 0,
        salesPrice: toNumber(row.salesPrice),
        mrp: toNumber(row.mrp),
        weightPerPiece: toNumber(row.weightPerPiece),
        length: toNumber(row.length),
        width: toNumber(row.width),
        height: toNumber(row.height),
        weight: toNumber(row.weight),
        imageUrl: row.imageUrl || "",
        images: row.images || [],
        isFeatured: toBoolean(row.isFeatured) || false,
        variantType: row.variantType || "",
        status: row.status?.toLowerCase() || "active",
        active: row.status?.toLowerCase() !== "inactive",
        posEnabled: toBoolean(row.posEnabled) || false,
        posConfig: {
          barcode: row.barcode || "",
          posPrice: toNumber(row.posPrice),
          allowDiscount: toBoolean(row.allowDiscount) !== false, // default true
          maxDiscountPercent: toInt(row.maxDiscountPercent) || 100,
          taxableInPOS: toBoolean(row.taxableInPOS) !== false,
          showInPOS: toBoolean(row.showInPOS) !== false,
        },
        includeGST: toBoolean(row.includeGST) !== false,
        includeIGST: toBoolean(row.includeIGST) || false,
        gstCode: row.gstCode || "",
        gstName: row.gstName || "",
        cgstRate: toNumber(row.cgstRate),
        sgstRate: toNumber(row.sgstRate),
        igstCode: row.igstCode || "",
        igstName: row.igstName || "",
        igstRate: toNumber(row.igstRate),
        vendorId: row.vendorId || null,
        commissionPercent: toNumber(row.commissionPercent) || 0,
        isMarketplace: toBoolean(row.isMarketplace) || false,
        includeQualityCheck: toBoolean(row.includeQualityCheck) || false,
        qualityCheckDetails: row.qualityCheckDetails || [],
        variants: normalizedVariants,
        gnr: toBoolean(row.gnr) || false,
        delivery: toBoolean(row.delivery) || false,
        productionProcess: toBoolean(row.productionProcess) || false,
        tags: row.tags || [],
        manufacturer: row.manufacturer || "",
        batchNumber: row.batchNumber || "",
        expiryDate: toDate(row.expiryDate),
        itemGroup: row.itemGroup || row.category || "",
      };

      // ── Handle itemCode ──
      let finalItemCode = row.itemCode ? row.itemCode.trim() : null;

      if (existingItem) {
        // UPDATE – keep existing itemCode
        Object.assign(existingItem, itemData);
        await existingItem.save();
        updatedCount++;
        results.push({
          row: i + 1,
          success: true,
          action: "updated",
          itemCode: existingItem.itemCode,
        });
      } else {
        // CREATE
        if (finalItemCode) {
          // Check if code already exists (safeguard)
          const codeExists = await Item.findOne({
            companyId: user.companyId,
            itemCode: finalItemCode,
          });
          if (codeExists) {
            skippedCount++;
            results.push({
              row: i + 1,
              success: false,
              errors: [`itemCode '${finalItemCode}' already exists`],
            });
            continue;
          }
        } else {
          finalItemCode = `ITEM-${currentNumber.toString().padStart(4, "0")}`;
          currentNumber++;
        }

        itemData.itemCode = finalItemCode;
        await Item.create(itemData);
        createdCount++;
        results.push({
          row: i + 1,
          success: true,
          action: "created",
          itemCode: finalItemCode,
        });
      }
    }

    const message = `Bulk upload complete: ${createdCount} created, ${updatedCount} updated, ${skippedCount} skipped.`;
    return NextResponse.json({
      success: true,
      message,
      results,
    });
  } catch (err) {
    console.error("Bulk upload error:", err);
    return NextResponse.json(
      { success: false, message: "Server error", error: err.message },
      { status: 500 }
    );
  }
}