import { NextResponse } from "next/server";
import connectDB from "@/lib/db";
import ProductionOrder from "@/models/ProductionOrder";
import BOM from "@/models/BOM";
import ReceiptProduction from "@/models/ReceiptProduction";
import Inventory from "@/models/Inventory";
import StockMovement from "@/models/StockMovement";
import { getTokenFromHeader, verifyJWT } from "@/lib/auth";

export async function POST(req, { params }) {
  try {
    await connectDB();

    // ✅ Await params – param name is `orderId`
    const { orderId } = await params;

    if (!orderId) {
      return NextResponse.json(
        { message: "Missing orderId in route params" },
        { status: 400 }
      );
    }

    // 🔐 Auth
    const token = getTokenFromHeader(req);
    if (!token) {
      return NextResponse.json({ message: "Unauthorized" }, { status: 401 });
    }
    const decoded = verifyJWT(token);
    if (!decoded) {
      return NextResponse.json({ message: "Invalid token" }, { status: 403 });
    }

    // 📦 Qty from query string
    const { searchParams } = new URL(req.url);
    const qtyParam = Number(searchParams.get("qty")) || 1;

    // 📝 Parse request body
    const body = await req.json();
    const { warehouse: sourceWarehouse, selectedBin, batches, unitPrice } = body;

    if (!sourceWarehouse) {
      return NextResponse.json({ message: "Warehouse is required" }, { status: 400 });
    }

    // 📦 Find order and populate BOM
    const order = await ProductionOrder.findById(orderId).populate("bomId");
    if (!order) {
      return NextResponse.json({ message: "Production Order not found" }, { status: 404 });
    }
    if (!order.bomId || !order.bomId.productNo) {
      return NextResponse.json({ message: "BOM or Product missing" }, { status: 400 });
    }

    // ✅ Get product ID
    const itemId = order.bomId.productNo._id || order.bomId.productNo;

    // ✅ Create ReceiptProduction record – added `item` field
    const receipt = await ReceiptProduction.create({
      productionOrder: orderId,
      item: itemId,                     // ✅ REQUIRED by schema
      createdBy: decoded.id,
      companyId: decoded.companyId,
      qty: qtyParam,
      sourceWarehouse,
      selectedBin: selectedBin || null,
      unitPrice: unitPrice || 0,
      batches: batches || [],
      date: body.date || new Date().toISOString().slice(0, 10),
      remarks: body.remarks || "",
    });

    // 📦 Update Inventory + Stock Movements – bin is optional
    const binFilter = selectedBin || null;

    if (batches && batches.length > 0) {
      for (const batch of batches) {
        const { batchNumber, quantity } = batch;
        if (!quantity || quantity <= 0) continue;

        let inventory = await Inventory.findOne({
          item: itemId,
          warehouse: sourceWarehouse,
          bin: binFilter,
          batchNumber: batchNumber || null,
        });

        if (inventory) {
          inventory.quantity += quantity;
          await inventory.save();
        } else {
          await Inventory.create({
            item: itemId,
            warehouse: sourceWarehouse,
            bin: binFilter,
            batchNumber: batchNumber || null,
            quantity,
          });
        }

        await StockMovement.create({
          companyId: decoded.companyId,
          createdBy: decoded.id,
          item: itemId,
          warehouse: sourceWarehouse,
          bin: binFilter,
          batchNumber: batchNumber || null,
          movementType: "IN",
          quantity,
          reference: receipt._id.toString(),
          remarks: `Receipt from Production Order ${orderId}`,
        });
      }
    } else {
      let inventory = await Inventory.findOne({
        item: itemId,
        warehouse: sourceWarehouse,
        bin: binFilter,
        batchNumber: null,
      });

      if (inventory) {
        inventory.quantity += qtyParam;
        await inventory.save();
      } else {
        await Inventory.create({
          item: itemId,
          warehouse: sourceWarehouse,
          bin: binFilter,
          batchNumber: null,
          quantity: qtyParam,
        });
      }

      await StockMovement.create({
        companyId: decoded.companyId,
        createdBy: decoded.id,
        item: itemId,
        warehouse: sourceWarehouse,
        bin: binFilter,
        batchNumber: null,
        movementType: "IN",
        quantity: qtyParam,
        reference: receipt._id.toString(),
        remarks: `Receipt from Production Order ${orderId}`,
      });
    }

    // ✅ Update Production Order
    const updatedOrder = await ProductionOrder.findByIdAndUpdate(
      orderId,
      {
        $inc: { receiptForProductionQty: qtyParam },
      },
      { new: true }
    );

    // ✅ Dynamic status
    const newReceiptQty = updatedOrder.receiptForProductionQty || 0;
    const totalQty = updatedOrder.quantity || 1;

    let newStatus = "In Progress";
    if (newReceiptQty >= totalQty) {
      newStatus = "Completed";
    }

    await ProductionOrder.findByIdAndUpdate(orderId, {
      $set: { status: newStatus },
    });

    return NextResponse.json(
      { success: true, receipt, newStatus },
      { status: 201 }
    );
  } catch (error) {
    console.error("Error in receipt-production:", error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}

// import { NextResponse } from "next/server";
// import connectDB from "@/lib/db";
// import ProductionOrder from "@/models/ProductionOrder";
// import ReceiptProduction from "@/models/ReceiptProduction";
// import Inventory from "@/models/Inventory";
// import BOM from "@/models/BOM";
// import { getTokenFromHeader, verifyJWT } from "@/lib/auth";

// export async function POST(req, contextPromise) {
//   try {
//     await connectDB();

//     const context = await contextPromise;
//     const { params } = context;
//     const { orderId } = params || {};

//     if (!orderId) {
//       return NextResponse.json({ message: 'Missing orderId in route params' }, { status: 400 });
//     }

//     const token = getTokenFromHeader(req);
//     if (!token) return NextResponse.json({ message: 'Unauthorized' }, { status: 401 });

//     const decoded = verifyJWT(token);
//     if (!decoded) return NextResponse.json({ message: 'Invalid token' }, { status: 403 });

//     const { qty } = Object.fromEntries(new URL(req.url).searchParams);
//     const qtyParam = parseFloat(qty || "1");

//     const body = await req.json();

//     const order = await ProductionOrder.findById(orderId).populate("bomId");
//     if (!order) return NextResponse.json({ message: 'Production Order not found' }, { status: 404 });

//     if (!order.bomId || !Array.isArray(order.bomId.items)) {
//       return NextResponse.json({ message: 'Invalid or missing BOM items' }, { status: 400 });
//     }
    

//     const sourceWarehouse = order?.warehouse || order?.bomId?.[0]?.warehouse;

// if (!sourceWarehouse) {
//   return NextResponse.json(
//     { error: "sourceWarehouse is required but not found in order or BOM" },
//     { status: 400 }
//   );
// }

//     // Step 1: Create ReceiptProduction
//     const receipt = await ReceiptProduction.create({
//       ...body,
//       productionOrder: orderId,
//       createdBy: decoded.id,
//       qty: qtyParam,
//       sourceWarehouse,
//     });

//     // Step 2: Update Inventory for each BOM item
//     for (const bomItem of order.bomId.items) {
//       const { item, quantity, warehouse } = bomItem;
//       const totalQuantity = quantity * qtyParam;

//       const existingInventory = await Inventory.findOne({ item, warehouse });

//       if (existingInventory) {
//         existingInventory.quantity += totalQuantity;
//         await existingInventory.save();
//       } else {
//         await Inventory.create({
//           item,
//           warehouse,
//           quantity: totalQuantity,
//         });
//       }
//     }

//     await ProductionOrder.findByIdAndUpdate(
//       orderId,
//       { $inc: { reciptforproductionqty: qtyParam } }
//     );

//     return NextResponse.json({ success: true, receipt }, { status: 201 });

//   } catch (error) {
//     console.error("Error in receipt-production:", error);
//     return NextResponse.json({ error: error.message }, { status: 500 });
//   }
// }





















