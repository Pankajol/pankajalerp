import { NextResponse } from "next/server";
import dbConnect from "@/lib/db";
import Operator from "@/models/ppc/operatorModel";
import { getTokenFromHeader, verifyJWT } from "@/lib/auth";

// ─── Auth helpers (keep your existing ones, unchanged) ──────────────────
function isAuthorized(user) {
  if (!user) return false;
  if (user.type === "company") return true;
  const allowedRoles = [
    "admin", "sales manager", "purchase manager", "inventory manager",
    "accounts manager", "hr manager", "support executive",
    "production head", "project manager",
  ];
  const userRoles = Array.isArray(user.roles) ? user.roles : [];
  return userRoles.some(role => allowedRoles.includes(role.trim().toLowerCase()));
}

async function validateUser(req) {
  const token = getTokenFromHeader(req);
  if (!token) return { error: "Token missing", status: 401 };
  try {
    const user = await verifyJWT(token);
    if (!user || !isAuthorized(user)) return { error: "Unauthorized", status: 403 };
    return { user };
  } catch {
    return { error: "Invalid token", status: 401 };
  }
}

// ─── GET ──────────────────────────────────────────────────────────────────
export async function GET(req) {
  await dbConnect();
  const { user, error, status } = await validateUser(req);
  if (error) return NextResponse.json({ success: false, message: error }, { status });

  let companyId = user.companyId;
  if (!companyId && user.type === "company") companyId = user.id || user._id;
  if (!companyId) companyId = user.company || user.company_id || user.orgId || user.organisation;
  if (!companyId) return NextResponse.json({ success: false, message: "No company identifier" }, { status: 400 });

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    const search = searchParams.get("search") || "";
    const statusFilter = searchParams.get("status");
    const page = Math.max(parseInt(searchParams.get("page")) || 1, 1);
    const limit = Math.min(parseInt(searchParams.get("limit")) || 50, 100);

    if (id) {
      const op = await Operator.findOne({ _id: id, companyId }).lean();
      if (!op) return NextResponse.json({ success: false, message: "Not found" }, { status: 404 });
      return NextResponse.json({ success: true, data: op });
    }

    const query = { companyId };
    if (search) {
      query.$or = [
        { operatorCode: { $regex: search, $options: "i" } },
        { name: { $regex: search, $options: "i" } },
      ];
    }
    if (statusFilter && statusFilter !== "all") query.status = statusFilter;

    const skip = (page - 1) * limit;
    const [operators, total] = await Promise.all([
      Operator.find(query).sort({ createdAt: -1 }).skip(skip).limit(limit).lean(),
      Operator.countDocuments(query),
    ]);

    return NextResponse.json({
      success: true,
      data: operators,
      meta: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (err) {
    console.error("GET error:", err);
    return NextResponse.json({ success: false, message: "Server error" }, { status: 500 });
  }
}

// ─── POST ────────────────────────────────────────────────────────────────
export async function POST(req) {
  await dbConnect();
  const { user, error, status } = await validateUser(req);
  if (error) return NextResponse.json({ success: false, message: error }, { status });

  // 🔐 Robust extraction of companyId from token
  let companyId = user.companyId;
  if (!companyId && user.type === "company") {
    companyId = user.id || user._id;
  }
  if (!companyId) {
    companyId = user.company || user.company_id || user.orgId || user.organisation;
  }

  if (!companyId) {
    console.error("❌ No companyId in token payload:", user);
    return NextResponse.json(
      { success: false, message: "Token does not contain a company identifier" },
      { status: 400 }
    );
  }

  try {
    const body = await req.json();
    const { operatorCode, name, skill, costPerHour, costPerDay, efficiency, status: bodyStatus } = body;

    if (!name || !operatorCode) {
      return NextResponse.json(
        { success: false, message: "Name and operator code are required" },
        { status: 400 }
      );
    }

    // Duplicate check
    const existing = await Operator.findOne({ operatorCode, companyId });
    if (existing) {
      return NextResponse.json(
        { success: false, message: `Operator code '${operatorCode}' already exists` },
        { status: 409 }
      );
    }

    // ✅ Data object – companyId is guaranteed to be present
    const data = {
      companyId,
      operatorCode,
      name,
      skill: skill || "other",
      costPerHour: parseFloat(costPerHour) || 0,
      costPerDay: parseFloat(costPerDay) || 0,
      efficiency: parseFloat(efficiency) || 100,
      status: bodyStatus || "active",
      createdBy: user.id || user._id,
    };

    // Temporary log – you can remove after confirming it works
    console.log("📌 Creating operator with data:", JSON.stringify(data, null, 2));

    const op = new Operator(data);
    await op.save();
    return NextResponse.json({ success: true, data: op, message: "Operator created" }, { status: 201 });
  } catch (err) {
    console.error("POST error:", err);
    return NextResponse.json({ success: false, message: err.message }, { status: 500 });
  }
}

// ─── PUT ─────────────────────────────────────────────────────────────────
export async function PUT(req) {
  await dbConnect();
  const { user, error, status } = await validateUser(req);
  if (error) return NextResponse.json({ success: false, message: error }, { status });

  let companyId = user.companyId;
  if (!companyId && user.type === "company") companyId = user.id || user._id;
  if (!companyId) companyId = user.company || user.company_id || user.orgId || user.organisation;
  if (!companyId) return NextResponse.json({ success: false, message: "No company identifier" }, { status: 400 });

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ success: false, message: "ID required" }, { status: 400 });

    const body = await req.json();
    delete body.companyId;
    delete body._id;

    const updated = await Operator.findOneAndUpdate(
      { _id: id, companyId },
      { $set: body },
      { new: true, runValidators: true }
    );

    if (!updated) return NextResponse.json({ success: false, message: "Not found" }, { status: 404 });
    return NextResponse.json({ success: true, data: updated, message: "Updated" });
  } catch (err) {
    console.error("PUT error:", err);
    return NextResponse.json({ success: false, message: err.message }, { status: 500 });
  }
}

// ─── DELETE ──────────────────────────────────────────────────────────────
export async function DELETE(req) {
  await dbConnect();
  const { user, error, status } = await validateUser(req);
  if (error) return NextResponse.json({ success: false, message: error }, { status });

  let companyId = user.companyId;
  if (!companyId && user.type === "company") companyId = user.id || user._id;
  if (!companyId) companyId = user.company || user.company_id || user.orgId || user.organisation;
  if (!companyId) return NextResponse.json({ success: false, message: "No company identifier" }, { status: 400 });

  try {
    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id) return NextResponse.json({ success: false, message: "ID required" }, { status: 400 });

    const deleted = await Operator.findOneAndDelete({ _id: id, companyId });
    if (!deleted) return NextResponse.json({ success: false, message: "Not found" }, { status: 404 });
    return NextResponse.json({ success: true, message: "Deleted" });
  } catch (err) {
    console.error("DELETE error:", err);
    return NextResponse.json({ success: false, message: err.message }, { status: 500 });
  }
}