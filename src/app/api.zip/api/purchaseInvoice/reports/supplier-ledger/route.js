import { NextResponse } from "next/server";
import mongoose from "mongoose";
import dbConnect from "@/lib/db";
import PurchaseInvoice from "@/models/InvoiceModel";
import Supplier from "@/models/SupplierModels";
import { getTokenFromHeader, verifyJWT } from "@/lib/auth";

export async function GET(req) {
  await dbConnect();

  const token = getTokenFromHeader(req);
  if (!token) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const decoded = verifyJWT(token);
  if (!decoded?.companyId) return NextResponse.json({ error: "Invalid token" }, { status: 403 });

  const { searchParams } = new URL(req.url);
  const supplierId = searchParams.get("supplierId");
  const startDate = searchParams.get("startDate");
  const endDate = searchParams.get("endDate");
  const page = parseInt(searchParams.get("page") || "1");
  const limit = parseInt(searchParams.get("limit") || "50");

  if (!supplierId) return NextResponse.json({ error: "supplierId is required" }, { status: 400 });

  // 1. Validate supplier
  const supplier = await Supplier.findOne({ _id: supplierId, companyId: decoded.companyId });
  if (!supplier) return NextResponse.json({ error: "Supplier not found" }, { status: 404 });

  // 2. Build match stage with strict date filtering
  const matchStage = {
    supplier: new mongoose.Types.ObjectId(supplierId),
    companyId: decoded.companyId,
  };
  if (startDate || endDate) {
    matchStage.documentDate = {};
    if (startDate) matchStage.documentDate.$gte = new Date(startDate);
    if (endDate) matchStage.documentDate.$lte = new Date(endDate);
  }

  // 3. Opening balance – ensure numeric conversion
  let openingBalance = 0;
  if (startDate) {
    const openMatch = {
      supplier: new mongoose.Types.ObjectId(supplierId),
      companyId: decoded.companyId,
      documentDate: { $lt: new Date(startDate) },
    };
    const openRes = await PurchaseInvoice.aggregate([
      { $match: openMatch },
      {
        $group: {
          _id: null,
          total: {
            $sum: {
              $subtract: [
                { $toDouble: "$grandTotal" },
                { $toDouble: "$paidAmount" },
              ],
            },
          },
        },
      },
    ]);
    openingBalance = openRes[0]?.total || 0;
  }

  // 4. Main pipeline – convert strings to numbers
  const pipeline = [
    { $match: matchStage },
    // Force numeric fields if they're stored as strings
    {
      $addFields: {
        grandTotalNum: { $toDouble: "$grandTotal" },
        paidAmountNum: { $toDouble: "$paidAmount" },
      },
    },
    { $sort: { documentDate: 1, createdAt: 1 } },
    {
      $project: {
        invoiceNo: "$documentNumberPurchaseInvoice",
        date: "$documentDate",
        grandTotal: "$grandTotalNum",
        paidAmount: "$paidAmountNum",
        remainingAmount: { $subtract: ["$grandTotalNum", "$paidAmountNum"] },
        paymentStatus: 1,
        remarks: 1,
      },
    },
    // $setWindowFields (MongoDB 5.0+)
    {
      $setWindowFields: {
        sortBy: { date: 1 },
        output: {
          runningBalance: {
            $sum: { $subtract: ["$grandTotal", "$paidAmount"] },
            window: { documents: ["unbounded", "current"] },
          },
        },
      },
    },
  ];

  // 5. Count total
  const totalRes = await PurchaseInvoice.aggregate([...pipeline, { $count: "total" }]);
  const totalRecords = totalRes[0]?.total || 0;

  // 6. Paginate
  const dataPipeline = [...pipeline, { $skip: (page - 1) * limit }, { $limit: limit }];
  const transactions = await PurchaseInvoice.aggregate(dataPipeline);

  // 7. Apply opening balance
  const transactionsWithOpening = transactions.map((t, idx) => {
    const running = openingBalance + (t.runningBalance || 0);
    return {
      ...t,
      openingBalance: idx === 0 ? openingBalance : undefined,
      runningBalance: running,
      closingBalance: running,
    };
  });

  const closingBalance =
    transactions.length > 0
      ? transactionsWithOpening[transactionsWithOpening.length - 1].closingBalance
      : openingBalance;

  // 🔍 Debug: log the first transaction so you can inspect in terminal
  if (transactions.length > 0) {
    console.log("First transaction (supplier-ledger):", transactions[0]);
  }

  return NextResponse.json({
    success: true,
    supplier: {
      _id: supplier._id,
      name: supplier.name || supplier.supplierName,
      code: supplier.supplierCode,
    },
    period: { startDate: startDate || null, endDate: endDate || null },
    openingBalance,
    closingBalance,
    transactions: transactionsWithOpening,
    pagination: {
      page,
      limit,
      total: totalRecords,
      pages: Math.ceil(totalRecords / limit),
    },
  });
}