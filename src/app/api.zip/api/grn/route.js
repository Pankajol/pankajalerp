import { NextResponse } from "next/server";
import mongoose, { Types } from "mongoose";
import { v2 as cloudinary } from "cloudinary";
import formidable from "formidable";
import { Readable } from "stream";
import dbConnect from "@/lib/db";
import GRN from "@/models/grnModels";
import PurchaseOrder from "@/models/PurchaseOrder";
import Supplier from "@/models/SupplierModels";
import ItemModels from "@/models/ItemModels";
import Inventory from "@/models/Inventory";
import StockMovement from "@/models/StockMovement";
import { getTokenFromHeader, verifyJWT } from "@/lib/auth";
import Counter from "@/models/Counter";

export const dynamic = 'force-dynamic';

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// ──────────────────────────────────────────────────────────────
// Helper: Convert NextRequest to Node.js readable stream for formidable
// ──────────────────────────────────────────────────────────────
function createNodeCompatibleRequest(req) {
  const nodeReq = Readable.fromWeb(req.body);
  nodeReq.headers = Object.fromEntries(req.headers.entries());
  nodeReq.method = req.method;
  return nodeReq;
}

// ──────────────────────────────────────────────────────────────
// Helper: Parse multipart form data
// ──────────────────────────────────────────────────────────────
async function parseForm(req) {
  return new Promise((resolve, reject) => {
    const form = formidable({ multiples: true, keepExtensions: true, maxFileSize: 10 * 1024 * 1024 });
    const nodeReq = createNodeCompatibleRequest(req);
    form.parse(nodeReq, (err, fields, files) => {
      if (err) { console.error("Formidable parse error:", err); return reject(err); }
      const parsedFields = {};
      for (const key in fields) parsedFields[key] = Array.isArray(fields[key]) ? fields[key][0] : fields[key];
      const parsedFiles = {};
      for (const key in files) parsedFiles[key] = Array.isArray(files[key]) ? files[key] : [files[key]];
      resolve({ fields: parsedFields, files: parsedFiles });
    });
  });
}

// ──────────────────────────────────────────────────────────────
// Helper: Upload files to Cloudinary
// ──────────────────────────────────────────────────────────────
async function uploadFiles(fileObjects, folderName, companyId) {
  const uploadedFiles = [];
  const fileArray = Array.isArray(fileObjects) ? fileObjects : [];
  for (const file of fileArray) {
    if (!file || !file.filepath) continue;
    try {
      const result = await cloudinary.uploader.upload(file.filepath, {
        folder: `${folderName}/${companyId || 'default_company'}`,
        resource_type: "auto",
        original_filename: file.originalFilename,
      });
      uploadedFiles.push({
        fileName: file.originalFilename || result.original_filename,
        fileUrl: result.secure_url,
        fileType: file.mimetype || "application/octet-stream",
        uploadedAt: new Date(),
        publicId: result.public_id,
      });
    } catch (uploadError) {
      console.error(`Cloudinary upload error for ${file.originalFilename}:`, uploadError);
      throw new Error(`Failed to upload file ${file.originalFilename}: ${uploadError.message}`);
    }
  }
  return uploadedFiles;
}

// ──────────────────────────────────────────────────────────────
// Helper: Delete files from Cloudinary by publicId
// ──────────────────────────────────────────────────────────────
async function deleteFilesByPublicIds(publicIds) {
  if (!publicIds || publicIds.length === 0) return;
  for (const publicId of publicIds) {
    try {
      await cloudinary.uploader.destroy(publicId);
    } catch (deleteError) {
      console.error(`Error deleting Cloudinary asset ${publicId}:`, deleteError);
    }
  }
}

// ──────────────────────────────────────────────────────────────
// Helper: Get item ID string from various formats
// ──────────────────────────────────────────────────────────────
function getItemId(itemRef) {
  if (!itemRef) return null;
  if (typeof itemRef === 'string') return itemRef;
  if (itemRef._id) return itemRef._id.toString();
  if (itemRef.toString) return itemRef.toString();
  return null;
}

// ──────────────────────────────────────────────────────────────
// Helper: Resolve variant ID from item object (with fallback by SKU)
// ──────────────────────────────────────────────────────────────
async function resolveVariantIdWithFallback(item, companyId) {
  if (!item) return null;
  let variantId = null;
  if (item.variant) {
    if (typeof item.variant === 'string') variantId = item.variant;
    else variantId = item.variant.variantId || item.variant._id || null;
  }
  if (!variantId && item.selectedVariantId) variantId = item.selectedVariantId;
  if (!variantId && item.variantId) variantId = item.variantId;

  // If still null, try to find by SKU (itemCode) in the Item model
  if (!variantId && item.itemCode && item.item) {
    try {
      const fullItem = await mongoose.model('Item').findById(item.item).select('variants').lean();
      if (fullItem && fullItem.variants) {
        const matched = fullItem.variants.find(v => v.sku === item.itemCode);
        if (matched) variantId = matched._id;
      }
    } catch (err) {
      console.warn('Could not fetch item to resolve variant by SKU:', err);
    }
  }

  return variantId;
}

// ──────────────────────────────────────────────────────────────
// Helper: Process a single GRN item (update inventory)
// ──────────────────────────────────────────────────────────────
async function processGrnItem(item, grnId, decoded, session, fromPO, isDelete = false) {
  const qty = Number(item.quantity);
  if (qty <= 0) throw new Error(`Invalid quantity (${qty}) for item ${item.itemCode || 'unknown'}`);
  
  const itemId = getItemId(item.item);
  const warehouseId = getItemId(item.warehouse);
  const variantId = await resolveVariantIdWithFallback(item, decoded.companyId);

  if (!itemId || !Types.ObjectId.isValid(itemId)) throw new Error(`Invalid item ID for ${item.itemCode || 'unknown'}`);
  if (!warehouseId || !Types.ObjectId.isValid(warehouseId)) throw new Error(`Invalid warehouse ID for ${item.itemCode || 'unknown'}`);

  console.log(`[Inventory] Processing: ${item.itemCode}, variantId: ${variantId}, qty: ${qty}, fromPO: ${fromPO}, isDelete: ${isDelete}`);

  let inventory = await Inventory.findOne({
    companyId: decoded.companyId,
    item: new Types.ObjectId(itemId),
    warehouse: new Types.ObjectId(warehouseId),
  }).session(session);

  if (!inventory) {
    if (isDelete) return;
    console.log(`Creating new inventory for item ${itemId}, warehouse ${warehouseId}`);
    inventory = new Inventory({
      companyId: decoded.companyId,
      item: new Types.ObjectId(itemId),
      warehouse: new Types.ObjectId(warehouseId),
      quantity: 0,
      committed: 0,
      onOrder: 0,
      hasVariants: !!variantId,
      variantInventory: [],
      batches: [],
    });
    await inventory.save({ session });
  }

  let effectiveVariantId = variantId;
  if (!effectiveVariantId && inventory.hasVariants) {
    const existingVariant = inventory.variantInventory.find(v => v.sku === item.itemCode);
    if (existingVariant) {
      effectiveVariantId = existingVariant.variantId;
      console.log(`Found variant by SKU in inventory: ${existingVariant.sku} -> ${effectiveVariantId}`);
    }
  }

  if (effectiveVariantId) {
    if (!inventory.hasVariants) {
      inventory.hasVariants = true;
      inventory.quantity = 0;
      inventory.committed = 0;
      inventory.onOrder = 0;
    }
  }

  function getVariantInv(variantId) {
    const variantObjId = new Types.ObjectId(variantId);
    let variantInv = inventory.variantInventory.find(v => v.variantId.toString() === variantObjId.toString());
    if (!variantInv) {
      if (isDelete) return null;
      variantInv = {
        variantId: variantObjId,
        sku: item.itemCode || `variant-${variantId}`,
        attributes: item.variant?.attributes || {},
        quantity: 0,
        committed: 0,
        onOrder: 0,
        batches: [],
      };
      inventory.variantInventory.push(variantInv);
    }
    return variantInv;
  }

  if (isDelete) {
    console.log(`Deleting GRN: reversing ${qty} units for ${item.itemCode}`);
    if (effectiveVariantId) {
      const vInv = getVariantInv(effectiveVariantId);
      if (vInv) {
        vInv.quantity = Math.max((vInv.quantity || 0) - qty, 0);
        if (fromPO) vInv.onOrder = (vInv.onOrder || 0) + qty;
        console.log(`Variant after reverse: quantity=${vInv.quantity}, onOrder=${vInv.onOrder}`);
      }
    } else {
      inventory.quantity = Math.max((inventory.quantity || 0) - qty, 0);
      if (fromPO) inventory.onOrder = (inventory.onOrder || 0) + qty;
      console.log(`Non-variant after reverse: quantity=${inventory.quantity}, onOrder=${inventory.onOrder}`);
    }
  } else {
    console.log(`Creating GRN: adding ${qty} units for ${item.itemCode}`);
    if (fromPO) {
      if (effectiveVariantId) {
        const vInv = getVariantInv(effectiveVariantId);
        if (vInv) {
          vInv.onOrder = Math.max((vInv.onOrder || 0) - qty, 0);
          console.log(`Variant onOrder reduced to ${vInv.onOrder}`);
        }
      } else {
        inventory.onOrder = Math.max((inventory.onOrder || 0) - qty, 0);
        console.log(`Non-variant onOrder reduced to ${inventory.onOrder}`);
      }
    }
    if (effectiveVariantId) {
      const vInv = getVariantInv(effectiveVariantId);
      if (vInv) {
        vInv.quantity = (vInv.quantity || 0) + qty;
        console.log(`Variant stock increased to ${vInv.quantity}`);
      }
    } else {
      inventory.quantity = (inventory.quantity || 0) + qty;
      console.log(`Non-variant stock increased to ${inventory.quantity}`);
    }
  }

  await inventory.save({ session });
  if (typeof inventory.updateStockStatus === 'function') await inventory.updateStockStatus();

  const movementType = isDelete ? 'REVERSAL' : 'IN';
  const remarks = isDelete 
    ? `GRN deleted, stock reversed${effectiveVariantId ? ` for variant ${item.itemCode}` : ''}`
    : `Stock received via GRN${effectiveVariantId ? ` for variant ${item.itemCode}` : ''}`;

  await StockMovement.create([{
    companyId: decoded.companyId,
    createdBy: decoded.id || decoded.userId,
    item: new Types.ObjectId(itemId),
    variantId: effectiveVariantId ? new Types.ObjectId(effectiveVariantId) : null,
    warehouse: new Types.ObjectId(warehouseId),
    movementType,
    quantity: qty,
    reference: grnId,
    referenceType: 'GRN',
    remarks,
    date: new Date(),
  }], { session });
}

// ──────────────────────────────────────────────────────────────
// Helper: Update Purchase Order status and receivedQuantity
// ──────────────────────────────────────────────────────────────
async function updatePurchaseOrder(poId, grnItems, session, isDelete = false) {
  if (!poId) {
    console.log('⚠️ No PO ID provided – skipping update.');
    return;
  }

  const po = await PurchaseOrder.findById(poId).session(session);
  if (!po) {
    console.log(`❌ PO ${poId} not found.`);
    return;
  }

  console.log(`📦 Updating PO ${po.documentNumberPurchaseOrder} (ID: ${poId})`);
  console.log(`   PO has ${po.items.length} item(s).`);
  console.log(`   PO items: ${JSON.stringify(po.items.map(i => ({
    id: getItemId(i.item),
    variant: i.variant,
    selectedVariantId: i.selectedVariantId,
    sku: i.itemCode,
    name: i.itemName
  })), null, 2)}`);

  const factor = isDelete ? -1 : 1;

  for (const grnItem of grnItems) {
    const qty = Number(grnItem.quantity);
    if (qty <= 0) continue;

    const grnItemId = getItemId(grnItem.item);
    const grnVariantId = await resolveVariantIdWithFallback(grnItem, po.companyId);
    const grnSku = grnItem.itemCode || '';

    console.log(`  🔍 Matching GRN item: ${grnSku} (itemId: ${grnItemId}, variantId: ${grnVariantId})`);

    let matchedPoItem = null;

    // Strategy 1: Exact itemId + variantId (both present)
    if (!matchedPoItem) {
      matchedPoItem = po.items.find(pi => {
        const piItemId = getItemId(pi.item);
        const piVariantId = pi.variant?.variantId || pi.selectedVariantId || null;
        return piItemId === grnItemId && piVariantId && grnVariantId && piVariantId.toString() === grnVariantId.toString();
      });
      if (matchedPoItem) console.log('    ✅ Matched by itemId + variantId');
    }

    // Strategy 2: itemId only (no variants)
    if (!matchedPoItem) {
      matchedPoItem = po.items.find(pi => {
        const piItemId = getItemId(pi.item);
        const piVariantId = pi.variant?.variantId || pi.selectedVariantId || null;
        return piItemId === grnItemId && !piVariantId && !grnVariantId;
      });
      if (matchedPoItem) console.log('    ✅ Matched by itemId only');
    }

    // Strategy 3: SKU match (itemCode)
    if (!matchedPoItem && grnSku) {
      matchedPoItem = po.items.find(pi => pi.itemCode === grnSku);
      if (matchedPoItem) console.log('    ✅ Matched by SKU');
    }

    // Strategy 4: variant SKU match (if PO has variant and GRN has sku)
    if (!matchedPoItem && grnSku) {
      matchedPoItem = po.items.find(pi => {
        const piVariantSku = pi.variant?.sku || pi.selectedVariantId;
        return piVariantSku && piVariantSku === grnSku;
      });
      if (matchedPoItem) console.log('    ✅ Matched by variant SKU');
    }

    if (matchedPoItem) {
      const currentReceived = Number(matchedPoItem.receivedQuantity || 0);
      const newReceived = Math.max(0, currentReceived + (qty * factor));
      matchedPoItem.receivedQuantity = newReceived;
      console.log(`    ✅ PO item "${matchedPoItem.itemCode}" (${matchedPoItem.itemName}): receivedQuantity ${currentReceived} → ${newReceived}`);
    } else {
      console.log(`    ❌ No matching PO item found for GRN item "${grnSku}"`);
    }
  }

  // Recalculate PO status
  const allItemsReceived = po.items.every(pi => {
    const ordered = Number(pi.quantity || 0);
    const received = Number(pi.receivedQuantity || 0);
    return ordered > 0 && received >= ordered;
  });
  const anyReceived = po.items.some(pi => Number(pi.receivedQuantity || 0) > 0);

  if (allItemsReceived) {
    po.orderStatus = 'FullyReceived';
  } else if (anyReceived) {
    po.orderStatus = 'PartiallyReceived';
  } else {
    po.orderStatus = 'Open';
  }
  console.log(`🏷️ PO status updated to: ${po.orderStatus}`);
  await po.save({ session });
}

// ──────────────────────────────────────────────────────────────
// POST /api/grn
// ──────────────────────────────────────────────────────────────
export async function POST(req) {
  await dbConnect();

  const token = getTokenFromHeader(req);
  if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  const decoded = verifyJWT(token);
  const companyId = decoded?.companyId;
  if (!companyId) return NextResponse.json({ success: false, error: "Invalid company ID" }, { status: 401 });

  const { fields, files } = await parseForm(req);
  const grnData = JSON.parse(fields.grnData || "{}");
  const removedFilesPublicIds = JSON.parse(fields.removedFiles || "[]");
  const existingFilesMetadata = JSON.parse(fields.existingFiles || "[]");

  if (!Array.isArray(grnData.items) || grnData.items.length === 0) {
    return NextResponse.json({ success: false, error: "Missing items" }, { status: 400 });
  }

  grnData.companyId = companyId;
  delete grnData._id;

  // File uploads
  const newUploadedFiles = await uploadFiles(files.newAttachments || [], "grn-attachments", companyId);
  grnData.attachments = [
    ...(existingFilesMetadata.filter(f => !removedFilesPublicIds.includes(f.publicId))),
    ...newUploadedFiles,
  ];
  await deleteFilesByPublicIds(removedFilesPublicIds);

  // Generate document number
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1;
  let fyStart = currentYear, fyEnd = currentYear + 1;
  if (currentMonth < 4) { fyStart = currentYear - 1; fyEnd = currentYear; }
  const financialYear = `${fyStart}-${String(fyEnd).slice(-2)}`;
  const key = "PurchaseGrn";

  let counter, retries = 3;
  while (retries > 0) {
    try {
      counter = await Counter.findOneAndUpdate(
        { id: key, companyId },
        { $inc: { seq: 1 } },
        { new: true, upsert: true }
      );
      break;
    } catch (err) {
      retries--;
      if (retries === 0) throw new Error("Failed to generate document number after retries");
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }
  grnData.documentNumberGrn = `PURCH-GRN/${financialYear}/${String(counter.seq).padStart(5, "0")}`;
  const fromPO = !!grnData.purchaseOrderId;

  console.log(`📋 Creating GRN ${grnData.documentNumberGrn}, fromPO: ${fromPO}, PO ID: ${grnData.purchaseOrderId || 'none'}`);

  let attempt = 0;
  const maxAttempts = 3;
  while (attempt < maxAttempts) {
    const session = await mongoose.startSession();
    try {
      session.startTransaction();

      const [grn] = await GRN.create([grnData], { session });

      for (const item of grnData.items) {
        await processGrnItem(item, grn._id, decoded, session, fromPO, false);
      }

      if (fromPO && grnData.purchaseOrderId) {
        await updatePurchaseOrder(grnData.purchaseOrderId, grnData.items, session, false);
      } else {
        console.log('⏭️ No PO to update (fromPO=false or missing purchaseOrderId)');
      }

      await session.commitTransaction();
      session.endSession();

      console.log(`✅ GRN ${grn.documentNumberGrn} created successfully`);
      return NextResponse.json(
        { success: true, message: "GRN created successfully", data: grn },
        { status: 201 }
      );
    } catch (error) {
      await session.abortTransaction();
      session.endSession();
      attempt++;
      console.error(`❌ Transaction attempt ${attempt} failed:`, error);
      if (attempt === maxAttempts) {
        return NextResponse.json({ success: false, error: error.message }, { status: 500 });
      }
      await new Promise(resolve => setTimeout(resolve, attempt * 100));
    }
  }
}

// ──────────────────────────────────────────────────────────────
// PUT /api/grn – Update GRN (no stock changes)
// ──────────────────────────────────────────────────────────────
export async function PUT(req) {
  const session = await mongoose.startSession();
  session.startTransaction();
  try {
    await dbConnect();
    const token = getTokenFromHeader(req);
    if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    const decoded = verifyJWT(token);
    if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid token" }, { status: 401 });

    const { fields, files } = await parseForm(req);
    const grnData = JSON.parse(fields.grnData || "{}");
    const removedFiles = JSON.parse(fields.removedFiles || "[]");
    const existingFiles = JSON.parse(fields.existingFiles || "[]");

    if (!grnData._id) return NextResponse.json({ success: false, error: "GRN ID required" }, { status: 400 });
    if (!Array.isArray(grnData.items) || grnData.items.length === 0) {
      return NextResponse.json({ success: false, error: "At least one item required" }, { status: 400 });
    }

    for (let i = 0; i < grnData.items.length; i++) {
      const item = grnData.items[i];
      if (!Types.ObjectId.isValid(item.item)) throw new Error(`Invalid item ID for row ${i + 1}`);
      if (!Types.ObjectId.isValid(item.warehouse)) throw new Error(`Invalid warehouse ID for row ${i + 1}`);
    }

    const newFiles = await uploadFiles(files.newAttachments || [], "grn-attachments", decoded.companyId);
    grnData.attachments = [...existingFiles, ...newFiles];
    for (const file of removedFiles) {
      if (file.publicId) await cloudinary.uploader.destroy(file.publicId);
    }

    const updatedGRN = await GRN.findByIdAndUpdate(grnData._id, grnData, { new: true, session });
    if (!updatedGRN) return NextResponse.json({ success: false, error: "GRN not found" }, { status: 404 });

    await session.commitTransaction();
    session.endSession();

    return NextResponse.json({ success: true, message: "GRN updated successfully", data: updatedGRN }, { status: 200 });
  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    console.error("PUT /api/grn error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

// ──────────────────────────────────────────────────────────────
// GET /api/grn – List or single GRN
// ──────────────────────────────────────────────────────────────
export async function GET(req) {
  try {
    await dbConnect();
    const token = getTokenFromHeader(req);
    if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    const decoded = verifyJWT(token);
    if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid token" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    const companyId = decoded.companyId;

    if (id) {
      const grn = await GRN.findOne({ _id: id, companyId })
        .populate("supplier", "supplierCode supplierName")
        .populate("items.item", "itemCode itemName imageUrl variants gstRate");
      if (!grn) return NextResponse.json({ success: false, error: "GRN not found" }, { status: 404 });
      return NextResponse.json({ success: true, data: grn }, { status: 200 });
    }

    const page = parseInt(searchParams.get("page")) || 1;
    const limit = parseInt(searchParams.get("limit")) || 10;
    const skip = (page - 1) * limit;

    const [grns, total] = await Promise.all([
      GRN.find({ companyId })
        .populate("supplier", "supplierCode supplierName")
        .populate("items.item", "itemCode itemName imageUrl variants gstRate")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit),
      GRN.countDocuments({ companyId }),
    ]);

    return NextResponse.json({
      success: true,
      data: grns,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) },
    });
  } catch (error) {
    console.error("GET /api/grn error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

// ──────────────────────────────────────────────────────────────
// DELETE /api/grn – Delete GRN and revert inventory & PO
// ──────────────────────────────────────────────────────────────
export async function DELETE(req) {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    await dbConnect();
    const token = getTokenFromHeader(req);
    if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    const decoded = verifyJWT(token);
    if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid token" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id || !Types.ObjectId.isValid(id)) {
      return NextResponse.json({ success: false, error: "Invalid GRN ID" }, { status: 400 });
    }

    const grn = await GRN.findOne({ _id: id, companyId: decoded.companyId }).session(session);
    if (!grn) {
      return NextResponse.json({ success: false, error: "GRN not found" }, { status: 404 });
    }

    const fromPO = !!grn.purchaseOrderId;
    console.log(`🗑️ Deleting GRN ${grn.documentNumberGrn}, fromPO: ${fromPO}`);

    // Reverse inventory
    for (const item of grn.items) {
      await processGrnItem(item, grn._id, decoded, session, fromPO, true);
    }

    // Update PO
    if (fromPO && grn.purchaseOrderId) {
      await updatePurchaseOrder(grn.purchaseOrderId, grn.items, session, true);
    }

    // Delete Cloudinary files
    if (grn.attachments && grn.attachments.length) {
      const publicIds = grn.attachments.map(a => a.publicId).filter(Boolean);
      await deleteFilesByPublicIds(publicIds);
    }

    await GRN.deleteOne({ _id: id, companyId: decoded.companyId }).session(session);

    await session.commitTransaction();
    session.endSession();

    console.log(`✅ GRN ${grn.documentNumberGrn} deleted successfully`);
    return NextResponse.json({ success: true, message: "GRN deleted successfully" }, { status: 200 });
  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    console.error("DELETE /api/grn error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}





// import { NextResponse } from "next/server";
// import mongoose, { Types } from "mongoose";
// import { v2 as cloudinary } from "cloudinary";
// import formidable from "formidable";
// import { Readable } from "stream";
// import dbConnect from "@/lib/db";
// import GRN from "@/models/grnModels";
// import PurchaseOrder from "@/models/PurchaseOrder";
// import Supplier from "@/models/SupplierModels";
// import ItemModels from "@/models/ItemModels";
// import Inventory from "@/models/Inventory";
// import StockMovement from "@/models/StockMovement";
// import { getTokenFromHeader, verifyJWT } from "@/lib/auth";
// import Counter from "@/models/Counter";

// export const dynamic = 'force-dynamic';

// cloudinary.config({
//   cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
//   api_key: process.env.CLOUDINARY_API_KEY,
//   api_secret: process.env.CLOUDINARY_API_SECRET,
// });

// // ──────────────────────────────────────────────────────────────
// // Helper: Convert NextRequest to Node.js readable stream for formidable
// // ──────────────────────────────────────────────────────────────
// function createNodeCompatibleRequest(req) {
//   const nodeReq = Readable.fromWeb(req.body);
//   nodeReq.headers = Object.fromEntries(req.headers.entries());
//   nodeReq.method = req.method;
//   return nodeReq;
// }

// // ──────────────────────────────────────────────────────────────
// // Helper: Parse multipart form data
// // ──────────────────────────────────────────────────────────────
// async function parseForm(req) {
//   return new Promise((resolve, reject) => {
//     const form = formidable({ multiples: true, keepExtensions: true, maxFileSize: 10 * 1024 * 1024 });
//     const nodeReq = createNodeCompatibleRequest(req);
//     form.parse(nodeReq, (err, fields, files) => {
//       if (err) { console.error("Formidable parse error:", err); return reject(err); }
//       const parsedFields = {};
//       for (const key in fields) parsedFields[key] = Array.isArray(fields[key]) ? fields[key][0] : fields[key];
//       const parsedFiles = {};
//       for (const key in files) parsedFiles[key] = Array.isArray(files[key]) ? files[key] : [files[key]];
//       resolve({ fields: parsedFields, files: parsedFiles });
//     });
//   });
// }

// // ──────────────────────────────────────────────────────────────
// // Helper: Upload files to Cloudinary
// // ──────────────────────────────────────────────────────────────
// async function uploadFiles(fileObjects, folderName, companyId) {
//   const uploadedFiles = [];
//   const fileArray = Array.isArray(fileObjects) ? fileObjects : [];
//   for (const file of fileArray) {
//     if (!file || !file.filepath) continue;
//     try {
//       const result = await cloudinary.uploader.upload(file.filepath, {
//         folder: `${folderName}/${companyId || 'default_company'}`,
//         resource_type: "auto",
//         original_filename: file.originalFilename,
//       });
//       uploadedFiles.push({
//         fileName: file.originalFilename || result.original_filename,
//         fileUrl: result.secure_url,
//         fileType: file.mimetype || "application/octet-stream",
//         uploadedAt: new Date(),
//         publicId: result.public_id,
//       });
//     } catch (uploadError) {
//       console.error(`Cloudinary upload error for ${file.originalFilename}:`, uploadError);
//       throw new Error(`Failed to upload file ${file.originalFilename}: ${uploadError.message}`);
//     }
//   }
//   return uploadedFiles;
// }

// // ──────────────────────────────────────────────────────────────
// // Helper: Delete files from Cloudinary by publicId
// // ──────────────────────────────────────────────────────────────
// async function deleteFilesByPublicIds(publicIds) {
//   if (!publicIds || publicIds.length === 0) return;
//   for (const publicId of publicIds) {
//     try {
//       await cloudinary.uploader.destroy(publicId);
//     } catch (deleteError) {
//       console.error(`Error deleting Cloudinary asset ${publicId}:`, deleteError);
//     }
//   }
// }

// // ──────────────────────────────────────────────────────────────
// // Helper: Get item ID string from various formats
// // ──────────────────────────────────────────────────────────────
// function getItemId(itemRef) {
//   if (!itemRef) return null;
//   if (typeof itemRef === 'string') return itemRef;
//   if (itemRef._id) return itemRef._id.toString();
//   if (itemRef.toString) return itemRef.toString();
//   return null;
// }

// // ──────────────────────────────────────────────────────────────
// // Helper: Resolve variant ID from item object (with fallback)
// // ──────────────────────────────────────────────────────────────
// async function resolveVariantIdWithFallback(item, companyId) {
//   if (!item) return null;
//   let variantId = null;
//   if (item.variant) {
//     if (typeof item.variant === 'string') variantId = item.variant;
//     else variantId = item.variant.variantId || item.variant._id || null;
//   }
//   if (!variantId && item.selectedVariantId) variantId = item.selectedVariantId;
//   if (!variantId && item.variantId) variantId = item.variantId;

//   // If still null, try to find by SKU (itemCode) in the Item model
//   if (!variantId && item.itemCode && item.item) {
//     try {
//       const fullItem = await mongoose.model('Item').findById(item.item).select('variants').lean();
//       if (fullItem && fullItem.variants) {
//         const matched = fullItem.variants.find(v => v.sku === item.itemCode);
//         if (matched) variantId = matched._id;
//       }
//     } catch (err) {
//       console.warn('Could not fetch item to resolve variant by SKU:', err);
//     }
//   }

//   return variantId;
// }

// // ──────────────────────────────────────────────────────────────
// // Helper: Process a single GRN item (update inventory)
// // ──────────────────────────────────────────────────────────────
// async function processGrnItem(item, grnId, decoded, session, fromPO, isDelete = false) {
//   const qty = Number(item.quantity);
//   if (qty <= 0) throw new Error(`Invalid quantity (${qty}) for item ${item.itemCode || 'unknown'}`);
  
//   const itemId = getItemId(item.item);
//   const warehouseId = getItemId(item.warehouse);
//   const variantId = await resolveVariantIdWithFallback(item, decoded.companyId);

//   if (!itemId || !Types.ObjectId.isValid(itemId)) throw new Error(`Invalid item ID for ${item.itemCode || 'unknown'}`);
//   if (!warehouseId || !Types.ObjectId.isValid(warehouseId)) throw new Error(`Invalid warehouse ID for ${item.itemCode || 'unknown'}`);

//   console.log(`Processing GRN item: ${item.itemCode}, variantId: ${variantId}, qty: ${qty}, fromPO: ${fromPO}, isDelete: ${isDelete}`);

//   // Find inventory
//   let inventory = await Inventory.findOne({
//     companyId: decoded.companyId,
//     item: new Types.ObjectId(itemId),
//     warehouse: new Types.ObjectId(warehouseId),
//   }).session(session);

//   if (!inventory) {
//     if (isDelete) return; // nothing to revert
//     console.log(`Creating new inventory for item ${itemId}, warehouse ${warehouseId}`);
//     inventory = new Inventory({
//       companyId: decoded.companyId,
//       item: new Types.ObjectId(itemId),
//       warehouse: new Types.ObjectId(warehouseId),
//       quantity: 0,
//       committed: 0,
//       onOrder: 0,
//       hasVariants: !!variantId,
//       variantInventory: [],
//       batches: [],
//     });
//     await inventory.save({ session });
//   }

//   // If the inventory already has variants, we must use variant-level fields
//   // Even if variantId is null, we should check if there is a variant entry matching the SKU
//   let effectiveVariantId = variantId;
//   if (!effectiveVariantId && inventory.hasVariants) {
//     // Try to find a variant by SKU in the inventory's variantInventory
//     const existingVariant = inventory.variantInventory.find(v => v.sku === item.itemCode);
//     if (existingVariant) {
//       effectiveVariantId = existingVariant.variantId;
//       console.log(`Found variant by SKU in inventory: ${existingVariant.sku} -> ${effectiveVariantId}`);
//     }
//   }

//   // If we have a variant ID, ensure hasVariants is true and zero out main fields
//   if (effectiveVariantId) {
//     if (!inventory.hasVariants) {
//       inventory.hasVariants = true;
//       inventory.quantity = 0;
//       inventory.committed = 0;
//       inventory.onOrder = 0;
//     }
//   }

//   // Helper to get or create variant inventory entry
//   function getVariantInv(variantId) {
//     const variantObjId = new Types.ObjectId(variantId);
//     let variantInv = inventory.variantInventory.find(v => v.variantId.toString() === variantObjId.toString());
//     if (!variantInv) {
//       if (isDelete) return null; // nothing to revert
//       // Create with default values
//       variantInv = {
//         variantId: variantObjId,
//         sku: item.itemCode || `variant-${variantId}`,
//         attributes: item.variant?.attributes || {},
//         quantity: 0,
//         committed: 0,
//         onOrder: 0,
//         batches: [],
//       };
//       inventory.variantInventory.push(variantInv);
//     }
//     return variantInv;
//   }

//   // ── Apply the change ──
//   if (isDelete) {
//     // Reverse: remove physical stock, restore onOrder (if from PO)
//     console.log(`Deleting GRN: reversing ${qty} units for item ${item.itemCode}`);
//     if (effectiveVariantId) {
//       const vInv = getVariantInv(effectiveVariantId);
//       if (vInv) {
//         vInv.quantity = Math.max((vInv.quantity || 0) - qty, 0);
//         if (fromPO) {
//           vInv.onOrder = (vInv.onOrder || 0) + qty;
//         }
//         console.log(`Variant after reverse: quantity=${vInv.quantity}, onOrder=${vInv.onOrder}`);
//       }
//     } else {
//       inventory.quantity = Math.max((inventory.quantity || 0) - qty, 0);
//       if (fromPO) {
//         inventory.onOrder = (inventory.onOrder || 0) + qty;
//       }
//       console.log(`Non-variant after reverse: quantity=${inventory.quantity}, onOrder=${inventory.onOrder}`);
//     }
//   } else {
//     // Normal GRN: reduce onOrder (if from PO), increase physical stock
//     console.log(`Creating GRN: adding ${qty} units for item ${item.itemCode}`);
//     if (fromPO) {
//       if (effectiveVariantId) {
//         const vInv = getVariantInv(effectiveVariantId);
//         if (vInv) {
//           vInv.onOrder = Math.max((vInv.onOrder || 0) - qty, 0);
//           console.log(`Variant onOrder reduced to ${vInv.onOrder}`);
//         }
//       } else {
//         inventory.onOrder = Math.max((inventory.onOrder || 0) - qty, 0);
//         console.log(`Non-variant onOrder reduced to ${inventory.onOrder}`);
//       }
//     }

//     // Increase physical stock
//     if (effectiveVariantId) {
//       const vInv = getVariantInv(effectiveVariantId);
//       if (vInv) {
//         vInv.quantity = (vInv.quantity || 0) + qty;
//         console.log(`Variant stock increased to ${vInv.quantity}`);
//       }
//     } else {
//       inventory.quantity = (inventory.quantity || 0) + qty;
//       console.log(`Non-variant stock increased to ${inventory.quantity}`);
//     }
//   }

//   await inventory.save({ session });

//   // Update stock status (if method exists)
//   if (typeof inventory.updateStockStatus === 'function') {
//     await inventory.updateStockStatus();
//   }

//   // ── Stock Movement log ──
//   const movementType = isDelete ? 'REVERSAL' : 'IN';
//   const remarks = isDelete 
//     ? `GRN deleted, stock reversed${effectiveVariantId ? ` for variant ${item.itemCode}` : ''}`
//     : `Stock received via GRN${effectiveVariantId ? ` for variant ${item.itemCode}` : ''}`;

//   await StockMovement.create([{
//     companyId: decoded.companyId,
//     createdBy: decoded.id || decoded.userId,
//     item: new Types.ObjectId(itemId),
//     variantId: effectiveVariantId ? new Types.ObjectId(effectiveVariantId) : null,
//     warehouse: new Types.ObjectId(warehouseId),
//     movementType,
//     quantity: qty,
//     reference: grnId,
//     referenceType: 'GRN',
//     remarks,
//     date: new Date(),
//   }], { session });
// }

// // ──────────────────────────────────────────────────────────────
// // Helper: Update Purchase Order status and receivedQuantity
// // ──────────────────────────────────────────────────────────────
// async function updatePurchaseOrder(poId, grnItems, session, isDelete = false) {
//   if (!poId) return;
//   const po = await PurchaseOrder.findById(poId).session(session);
//   if (!po) {
//     console.log(`PO ${poId} not found`);
//     return;
//   }

//   const factor = isDelete ? -1 : 1;

//   for (const grnItem of grnItems) {
//     const grnItemId = getItemId(grnItem.item);
//     const grnVariantId = await resolveVariantIdWithFallback(grnItem, po.companyId);
//     const qty = Number(grnItem.quantity);

//     // Find matching PO item by item ID and variant ID
//     const poItem = po.items.find(pi => {
//       const piItemId = getItemId(pi.item);
//       const piVariantId = pi.variant?.variantId || pi.selectedVariantId || null;
//       // If PO item has a variant but the GRN item doesn't, try to match by SKU
//       if (piVariantId && !grnVariantId && pi.itemCode === grnItem.itemCode) {
//         return piItemId === grnItemId;
//       }
//       return piItemId === grnItemId && piVariantId === grnVariantId;
//     });

//     if (poItem) {
//       const currentReceived = Number(poItem.receivedQuantity || 0);
//       poItem.receivedQuantity = Math.max(0, currentReceived + (qty * factor));
//       console.log(`PO item ${poItem.itemCode}: receivedQuantity now ${poItem.receivedQuantity}`);
//     } else {
//       console.log(`PO item not found for GRN item ${grnItem.itemCode} (ID: ${grnItemId}, variant: ${grnVariantId})`);
//     }
//   }

//   // Recalculate PO status
//   const allItemsReceived = po.items.every(pi => {
//     const ordered = Number(pi.quantity || 0);
//     const received = Number(pi.receivedQuantity || 0);
//     return ordered > 0 && received >= ordered;
//   });
//   const anyReceived = po.items.some(pi => Number(pi.receivedQuantity || 0) > 0);

//   if (allItemsReceived) {
//     po.orderStatus = 'FullyReceived';
//   } else if (anyReceived) {
//     po.orderStatus = 'PartiallyReceived';
//   } else {
//     po.orderStatus = 'Open';
//   }
//   console.log(`PO ${po.documentNumberPurchaseOrder} status updated to ${po.orderStatus}`);
//   await po.save({ session });
// }

// // ──────────────────────────────────────────────────────────────
// // POST /api/grn
// // ──────────────────────────────────────────────────────────────
// export async function POST(req) {
//   await dbConnect();

//   const token = getTokenFromHeader(req);
//   if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
//   const decoded = verifyJWT(token);
//   const companyId = decoded?.companyId;
//   if (!companyId) return NextResponse.json({ success: false, error: "Invalid company ID" }, { status: 401 });

//   const { fields, files } = await parseForm(req);
//   const grnData = JSON.parse(fields.grnData || "{}");
//   const removedFilesPublicIds = JSON.parse(fields.removedFiles || "[]");
//   const existingFilesMetadata = JSON.parse(fields.existingFiles || "[]");

//   if (!Array.isArray(grnData.items) || grnData.items.length === 0) {
//     return NextResponse.json({ success: false, error: "Missing items" }, { status: 400 });
//   }

//   grnData.companyId = companyId;
//   delete grnData._id;

//   // Handle file uploads
//   const newUploadedFiles = await uploadFiles(files.newAttachments || [], "grn-attachments", companyId);
//   grnData.attachments = [
//     ...(existingFilesMetadata.filter(f => !removedFilesPublicIds.includes(f.publicId))),
//     ...newUploadedFiles,
//   ];
//   await deleteFilesByPublicIds(removedFilesPublicIds);

//   // Generate document number
//   const now = new Date();
//   const currentYear = now.getFullYear();
//   const currentMonth = now.getMonth() + 1;
//   let fyStart = currentYear, fyEnd = currentYear + 1;
//   if (currentMonth < 4) { fyStart = currentYear - 1; fyEnd = currentYear; }
//   const financialYear = `${fyStart}-${String(fyEnd).slice(-2)}`;
//   const key = "PurchaseGrn";

//   let counter, retries = 3;
//   while (retries > 0) {
//     try {
//       counter = await Counter.findOneAndUpdate(
//         { id: key, companyId },
//         { $inc: { seq: 1 } },
//         { new: true, upsert: true }
//       );
//       break;
//     } catch (err) {
//       retries--;
//       if (retries === 0) throw new Error("Failed to generate document number after retries");
//       await new Promise(resolve => setTimeout(resolve, 100));
//     }
//   }
//   grnData.documentNumberGrn = `PURCH-GRN/${financialYear}/${String(counter.seq).padStart(5, "0")}`;
//   const fromPO = !!grnData.purchaseOrderId;

//   console.log(`Creating GRN ${grnData.documentNumberGrn}, fromPO: ${fromPO}`);

//   // Retry loop for transaction
//   let attempt = 0;
//   const maxAttempts = 3;
//   while (attempt < maxAttempts) {
//     const session = await mongoose.startSession();
//     try {
//       session.startTransaction();

//       // Create GRN
//       const [grn] = await GRN.create([grnData], { session });

//       // Process inventory for each item
//       for (const item of grnData.items) {
//         await processGrnItem(item, grn._id, decoded, session, fromPO, false);
//       }

//       // Update Purchase Order
//       if (fromPO && grnData.purchaseOrderId) {
//         await updatePurchaseOrder(grnData.purchaseOrderId, grnData.items, session, false);
//       }

//       await session.commitTransaction();
//       session.endSession();

//       console.log(`GRN ${grn.documentNumberGrn} created successfully`);
//       return NextResponse.json(
//         { success: true, message: "GRN created successfully", data: grn },
//         { status: 201 }
//       );
//     } catch (error) {
//       await session.abortTransaction();
//       session.endSession();
//       attempt++;
//       console.error(`Transaction attempt ${attempt} failed:`, error);
//       if (attempt === maxAttempts) {
//         return NextResponse.json({ success: false, error: error.message }, { status: 500 });
//       }
//       await new Promise(resolve => setTimeout(resolve, attempt * 100));
//     }
//   }
// }

// // ──────────────────────────────────────────────────────────────
// // PUT /api/grn – Update GRN (no stock changes)
// // ──────────────────────────────────────────────────────────────
// export async function PUT(req) {
//   const session = await mongoose.startSession();
//   session.startTransaction();
//   try {
//     await dbConnect();
//     const token = getTokenFromHeader(req);
//     if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
//     const decoded = verifyJWT(token);
//     if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid token" }, { status: 401 });

//     const { fields, files } = await parseForm(req);
//     const grnData = JSON.parse(fields.grnData || "{}");
//     const removedFiles = JSON.parse(fields.removedFiles || "[]");
//     const existingFiles = JSON.parse(fields.existingFiles || "[]");

//     if (!grnData._id) return NextResponse.json({ success: false, error: "GRN ID required" }, { status: 400 });
//     if (!Array.isArray(grnData.items) || grnData.items.length === 0) {
//       return NextResponse.json({ success: false, error: "At least one item required" }, { status: 400 });
//     }

//     for (let i = 0; i < grnData.items.length; i++) {
//       const item = grnData.items[i];
//       if (!Types.ObjectId.isValid(item.item)) throw new Error(`Invalid item ID for row ${i + 1}`);
//       if (!Types.ObjectId.isValid(item.warehouse)) throw new Error(`Invalid warehouse ID for row ${i + 1}`);
//     }

//     const newFiles = await uploadFiles(files.newAttachments || [], "grn-attachments", decoded.companyId);
//     grnData.attachments = [...existingFiles, ...newFiles];
//     for (const file of removedFiles) {
//       if (file.publicId) await cloudinary.uploader.destroy(file.publicId);
//     }

//     const updatedGRN = await GRN.findByIdAndUpdate(grnData._id, grnData, { new: true, session });
//     if (!updatedGRN) return NextResponse.json({ success: false, error: "GRN not found" }, { status: 404 });

//     await session.commitTransaction();
//     session.endSession();

//     return NextResponse.json({ success: true, message: "GRN updated successfully", data: updatedGRN }, { status: 200 });
//   } catch (error) {
//     await session.abortTransaction();
//     session.endSession();
//     console.error("PUT /api/grn error:", error);
//     return NextResponse.json({ success: false, error: error.message }, { status: 500 });
//   }
// }

// // ──────────────────────────────────────────────────────────────
// // GET /api/grn – List or single GRN
// // ──────────────────────────────────────────────────────────────
// export async function GET(req) {
//   try {
//     await dbConnect();
//     const token = getTokenFromHeader(req);
//     if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
//     const decoded = verifyJWT(token);
//     if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid token" }, { status: 401 });

//     const { searchParams } = new URL(req.url);
//     const id = searchParams.get("id");
//     const companyId = decoded.companyId;

//     if (id) {
//       const grn = await GRN.findOne({ _id: id, companyId })
//         .populate("supplier", "supplierCode supplierName")
//         .populate("items.item", "itemCode itemName imageUrl variants gstRate");
//       if (!grn) return NextResponse.json({ success: false, error: "GRN not found" }, { status: 404 });
//       return NextResponse.json({ success: true, data: grn }, { status: 200 });
//     }

//     const page = parseInt(searchParams.get("page")) || 1;
//     const limit = parseInt(searchParams.get("limit")) || 10;
//     const skip = (page - 1) * limit;

//     const [grns, total] = await Promise.all([
//       GRN.find({ companyId })
//         .populate("supplier", "supplierCode supplierName")
//         .populate("items.item", "itemCode itemName imageUrl variants gstRate")
//         .sort({ createdAt: -1 })
//         .skip(skip)
//         .limit(limit),
//       GRN.countDocuments({ companyId }),
//     ]);

//     return NextResponse.json({
//       success: true,
//       data: grns,
//       pagination: { page, limit, total, pages: Math.ceil(total / limit) },
//     });
//   } catch (error) {
//     console.error("GET /api/grn error:", error);
//     return NextResponse.json({ success: false, error: error.message }, { status: 500 });
//   }
// }

// // ──────────────────────────────────────────────────────────────
// // DELETE /api/grn – Delete GRN and revert inventory & PO
// // ──────────────────────────────────────────────────────────────
// export async function DELETE(req) {
//   const session = await mongoose.startSession();
//   session.startTransaction();

//   try {
//     await dbConnect();
//     const token = getTokenFromHeader(req);
//     if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
//     const decoded = verifyJWT(token);
//     if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid token" }, { status: 401 });

//     const { searchParams } = new URL(req.url);
//     const id = searchParams.get("id");
//     if (!id || !Types.ObjectId.isValid(id)) {
//       return NextResponse.json({ success: false, error: "Invalid GRN ID" }, { status: 400 });
//     }

//     const grn = await GRN.findOne({ _id: id, companyId: decoded.companyId }).session(session);
//     if (!grn) {
//       return NextResponse.json({ success: false, error: "GRN not found" }, { status: 404 });
//     }

//     const fromPO = !!grn.purchaseOrderId;
//     console.log(`Deleting GRN ${grn.documentNumberGrn}, fromPO: ${fromPO}`);

//     // Reverse inventory changes
//     for (const item of grn.items) {
//       await processGrnItem(item, grn._id, decoded, session, fromPO, true);
//     }

//     // Update Purchase Order (reduce received quantities)
//     if (fromPO && grn.purchaseOrderId) {
//       await updatePurchaseOrder(grn.purchaseOrderId, grn.items, session, true);
//     }

//     // Delete Cloudinary files
//     if (grn.attachments && grn.attachments.length) {
//       const publicIds = grn.attachments.map(a => a.publicId).filter(Boolean);
//       await deleteFilesByPublicIds(publicIds);
//     }

//     // Delete GRN document
//     await GRN.deleteOne({ _id: id, companyId: decoded.companyId }).session(session);

//     await session.commitTransaction();
//     session.endSession();

//     console.log(`GRN ${grn.documentNumberGrn} deleted successfully`);
//     return NextResponse.json({ success: true, message: "GRN deleted successfully" }, { status: 200 });
//   } catch (error) {
//     await session.abortTransaction();
//     session.endSession();
//     console.error("DELETE /api/grn error:", error);
//     return NextResponse.json({ success: false, error: error.message }, { status: 500 });
//   }
// }

// import { NextResponse } from "next/server";
// import mongoose, { Types } from "mongoose";
// import { v2 as cloudinary } from "cloudinary";
// import formidable from "formidable";
// import { Readable } from "stream";
// import dbConnect from "@/lib/db";
// import GRN from "@/models/grnModels";
// import PurchaseOrder from "@/models/PurchaseOrder";
// import Inventory from "@/models/Inventory";
// import StockMovement from "@/models/StockMovement";
// import { getTokenFromHeader, verifyJWT } from "@/lib/auth";
// import Counter from "@/models/Counter";
// import Supplier from "@/models/SupplierModels";
// import ItemModels from "@/models/ItemModels";

// // Accounting (optional)
// import { autoGRN } from "@/lib/autoTransaction";

// export const dynamic = 'force-dynamic';

// cloudinary.config({
//   cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
//   api_key: process.env.CLOUDINARY_API_KEY,
//   api_secret: process.env.CLOUDINARY_API_SECRET,
// });

// // ──────────────────────────────────────────────────────────────
// // Helper: Convert NextRequest to Node.js readable stream for formidable
// // ──────────────────────────────────────────────────────────────
// function createNodeCompatibleRequest(req) {
//   const nodeReq = Readable.fromWeb(req.body);
//   nodeReq.headers = Object.fromEntries(req.headers.entries());
//   nodeReq.method = req.method;
//   return nodeReq;
// }

// // ──────────────────────────────────────────────────────────────
// // Helper: Parse multipart form data
// // ──────────────────────────────────────────────────────────────
// async function parseForm(req) {
//   return new Promise((resolve, reject) => {
//     const form = formidable({ multiples: true, keepExtensions: true, maxFileSize: 10 * 1024 * 1024 });
//     const nodeReq = createNodeCompatibleRequest(req);
//     form.parse(nodeReq, (err, fields, files) => {
//       if (err) { console.error("Formidable parse error:", err); return reject(err); }
//       const parsedFields = {};
//       for (const key in fields) parsedFields[key] = Array.isArray(fields[key]) ? fields[key][0] : fields[key];
//       const parsedFiles = {};
//       for (const key in files) parsedFiles[key] = Array.isArray(files[key]) ? files[key] : [files[key]];
//       resolve({ fields: parsedFields, files: parsedFiles });
//     });
//   });
// }

// // ──────────────────────────────────────────────────────────────
// // Helper: Upload files to Cloudinary
// // ──────────────────────────────────────────────────────────────
// async function uploadFiles(fileObjects, folderName, companyId) {
//   const uploadedFiles = [];
//   const fileArray = Array.isArray(fileObjects) ? fileObjects : [];
//   for (const file of fileArray) {
//     if (!file || !file.filepath) continue;
//     try {
//       const result = await cloudinary.uploader.upload(file.filepath, {
//         folder: `${folderName}/${companyId || 'default_company'}`,
//         resource_type: "auto",
//         original_filename: file.originalFilename,
//       });
//       uploadedFiles.push({
//         fileName: file.originalFilename || result.original_filename,
//         fileUrl: result.secure_url,
//         fileType: file.mimetype || "application/octet-stream",
//         uploadedAt: new Date(),
//         publicId: result.public_id,
//       });
//     } catch (uploadError) {
//       console.error(`Cloudinary upload error for ${file.originalFilename}:`, uploadError);
//       throw new Error(`Failed to upload file ${file.originalFilename}: ${uploadError.message}`);
//     }
//   }
//   return uploadedFiles;
// }

// // ──────────────────────────────────────────────────────────────
// // Helper: Delete files from Cloudinary by publicId
// // ──────────────────────────────────────────────────────────────
// async function deleteFilesByPublicIds(publicIds) {
//   if (!publicIds || publicIds.length === 0) return;
//   for (const publicId of publicIds) {
//     try {
//       await cloudinary.uploader.destroy(publicId);
//     } catch (deleteError) {
//       console.error(`Error deleting Cloudinary asset ${publicId}:`, deleteError);
//     }
//   }
// }

// // ──────────────────────────────────────────────────────────────
// // Helper: Process a single GRN item (update inventory)
// // Used in POST and also in DELETE (reverse operation)
// // ──────────────────────────────────────────────────────────────
// async function processGrnItem(item, grnId, decodedToken, session, fromPO, isDelete = false) {
//   const qty = Number(item.quantity);
//   const itemId = item.item?._id || item.item;
//   const warehouseId = item.warehouse?._id || item.warehouse;
//   const binId = item.selectedBin?._id || item.selectedBin || null;
//   const variantId = item.variant?.variantId || item.selectedVariantId;

//   if (!itemId || !Types.ObjectId.isValid(itemId) || !warehouseId || !Types.ObjectId.isValid(warehouseId) || qty <= 0) {
//     throw new Error(`Invalid GRN item for ${item.itemCode || 'unknown'}`);
//   }

//   // Find inventory document
//   let inventory = await Inventory.findOne({
//     companyId: decodedToken.companyId,
//     item: new Types.ObjectId(itemId),
//     warehouse: new Types.ObjectId(warehouseId),
//   }).session(session);

//   if (!inventory) {
//     // Should not happen when deleting, but create if necessary
//     inventory = new Inventory({
//       companyId: decodedToken.companyId,
//       item: new Types.ObjectId(itemId),
//       warehouse: new Types.ObjectId(warehouseId),
//       quantity: 0,
//       committed: 0,
//       onOrder: 0,
//       batches: [],
//       hasVariants: !!variantId,
//       variantInventory: [],
//     });
//   }

//   if (isDelete) {
//     // Reverse operation: remove physical stock and increase onOrder
//     if (variantId) {
//       let variantInv = inventory.variantInventory.find(v => v.variantId.toString() === variantId.toString());
//       if (!variantInv) {
//         variantInv = {
//           variantId: new Types.ObjectId(variantId),
//           sku: item.itemCode,
//           attributes: item.variant?.attributes || {},
//           quantity: 0,
//           committed: 0,
//           onOrder: 0,
//           batches: []
//         };
//         inventory.variantInventory.push(variantInv);
//       }
//       variantInv.quantity = Math.max((variantInv.quantity || 0) - qty, 0);
//       if (fromPO) {
//         variantInv.onOrder = (variantInv.onOrder || 0) + qty;
//       }
//     } else {
//       inventory.quantity = Math.max((inventory.quantity || 0) - qty, 0);
//       if (fromPO) {
//         inventory.onOrder = (inventory.onOrder || 0) + qty;
//       }
//     }
//   } else {
//     // Normal POST operation: reduce onOrder (if from PO), increase physical stock
//     if (fromPO) {
//       if (variantId) {
//         let variantInv = inventory.variantInventory.find(v => v.variantId.toString() === variantId.toString());
//         if (!variantInv) {
//           variantInv = {
//             variantId: new Types.ObjectId(variantId),
//             sku: item.itemCode,
//             attributes: item.variant?.attributes || {},
//             quantity: 0,
//             committed: 0,
//             onOrder: 0,
//             batches: []
//           };
//           inventory.variantInventory.push(variantInv);
//         }
//         variantInv.onOrder = Math.max((variantInv.onOrder || 0) - qty, 0);
//       } else {
//         inventory.onOrder = Math.max((inventory.onOrder || 0) - qty, 0);
//       }
//     }

//     if (variantId) {
//       let variantInv = inventory.variantInventory.find(v => v.variantId.toString() === variantId.toString());
//       if (!variantInv) {
//         variantInv = {
//           variantId: new Types.ObjectId(variantId),
//           sku: item.itemCode,
//           attributes: item.variant?.attributes || {},
//           quantity: 0,
//           committed: 0,
//           onOrder: 0,
//           batches: []
//         };
//         inventory.variantInventory.push(variantInv);
//       }
//       variantInv.quantity += qty;
//     } else {
//       inventory.quantity += qty;
//     }
//   }

//   // Batch adjustments (if any) – for delete we would need to revert batches too, but that's complex.
//   // For simplicity, we skip batch reversal on delete; you can implement if needed.

//   await inventory.save({ session });
//   await inventory.updateStockStatus(); // if you have such method

//   // Log stock movement (only for POST, not for DELETE reversal)
//   if (!isDelete) {
//     await StockMovement.create([{
//       companyId: decodedToken.companyId,
//       createdBy: decodedToken.userId || decodedToken.id,
//       item: new Types.ObjectId(itemId),
//       variantId: variantId ? new Types.ObjectId(variantId) : null,
//       warehouse: new Types.ObjectId(warehouseId),
//       bin: binId ? new Types.ObjectId(binId) : null,
//       movementType: "IN",
//       quantity: qty,
//       reference: grnId,
//       referenceType: "GRN",
//       remarks: `Stock received via GRN${variantId ? ` for variant ${item.itemCode}` : ''}`,
//       date: new Date()
//     }], { session });
//   } else {
//     // Optionally log a reversal movement
//     await StockMovement.create([{
//       companyId: decodedToken.companyId,
//       createdBy: decodedToken.userId || decodedToken.id,
//       item: new Types.ObjectId(itemId),
//       variantId: variantId ? new Types.ObjectId(variantId) : null,
//       warehouse: new Types.ObjectId(warehouseId),
//       bin: binId ? new Types.ObjectId(binId) : null,
//       movementType: "REVERSAL",
//       quantity: qty,
//       reference: grnId,
//       referenceType: "GRN",
//       remarks: `GRN deleted, stock reversed${variantId ? ` for variant ${item.itemCode}` : ''}`,
//       date: new Date()
//     }], { session });
//   }
// }

// // ──────────────────────────────────────────────────────────────
// // POST /api/grn
// // ──────────────────────────────────────────────────────────────
// // ──────────────────────────────────────────────────────────────
// // POST /api/grn (with retry & counter outside transaction)
// // ──────────────────────────────────────────────────────────────
// export async function POST(req) {
//   await dbConnect();

//   // 1. Parse and prepare data outside transaction
//   const token = getTokenFromHeader(req);
//   if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
//   const decoded = verifyJWT(token);
//   const companyId = decoded?.companyId;
//   if (!companyId) return NextResponse.json({ success: false, error: "Invalid company ID" }, { status: 401 });

//   const { fields, files } = await parseForm(req);
//   const grnData = JSON.parse(fields.grnData || "{}");
//   const removedFilesPublicIds = JSON.parse(fields.removedFiles || "[]");
//   const existingFilesMetadata = JSON.parse(fields.existingFiles || "[]");

//   if (!Array.isArray(grnData.items) || grnData.items.length === 0) {
//     return NextResponse.json({ success: false, error: "Missing items" }, { status: 400 });
//   }

//   grnData.companyId = companyId;
//   delete grnData._id;

//   // 2. Handle file uploads (can be done outside)
//   const newUploadedFiles = await uploadFiles(files.newAttachments || [], "grn-attachments", companyId);
//   grnData.attachments = [
//     ...(existingFilesMetadata.filter(f => !removedFilesPublicIds.includes(f.publicId))),
//     ...newUploadedFiles,
//   ];
//   await deleteFilesByPublicIds(removedFilesPublicIds);

//   // 3. Generate document number (outside transaction – atomic but independent)
//   const now = new Date();
//   const currentYear = now.getFullYear();
//   const currentMonth = now.getMonth() + 1;
//   let fyStart = currentYear, fyEnd = currentYear + 1;
//   if (currentMonth < 4) { fyStart = currentYear - 1; fyEnd = currentYear; }
//   const financialYear = `${fyStart}-${String(fyEnd).slice(-2)}`;
//   const key = "PurchaseGrn";

//   // Retry counter update a few times if needed
//   let counter;
//   let retries = 3;
//   while (retries > 0) {
//     try {
//       counter = await Counter.findOneAndUpdate(
//         { id: key, companyId },
//         { $inc: { seq: 1 } },
//         { new: true, upsert: true }
//       );
//       break;
//     } catch (err) {
//       retries--;
//       if (retries === 0) throw new Error("Failed to generate document number after retries");
//       await new Promise(resolve => setTimeout(resolve, 100));
//     }
//   }
//   grnData.documentNumberGrn = `PURCH-GRN/${financialYear}/${String(counter.seq).padStart(5, "0")}`;
//   const fromPO = !!grnData.purchaseOrderId;

//   // 4. Retry logic for the main transaction (handles inventory & PO updates)
//   let attempt = 0;
//   const maxAttempts = 3;
//   while (attempt < maxAttempts) {
//     const session = await mongoose.startSession();
//     try {
//       session.startTransaction();

//       // Create GRN document
//       const [grn] = await GRN.create([grnData], { session });

//       // Process each item (inventory & stock movement)
//       for (const item of grnData.items) {
//         await processGrnItem(item, grn._id, decoded, session, fromPO, false);
//       }

//       // Update linked Purchase Order
//       if (fromPO && grnData.purchaseOrderId) {
//         const po = await PurchaseOrder.findById(grnData.purchaseOrderId).session(session);
//         if (po) {
//           for (const grnItem of grnData.items) {
//             const poItem = po.items.find(pi => pi.item.toString() === (grnItem.item?._id || grnItem.item));
//             if (poItem) {
//               poItem.receivedQuantity = (poItem.receivedQuantity || 0) + grnItem.quantity;
//             }
//           }
//           const fullyReceived = po.items.every(pi => (pi.receivedQuantity || 0) >= (pi.quantity || 0));
//           const anyReceived = po.items.some(pi => (pi.receivedQuantity || 0) > 0);
//           if (fullyReceived) po.orderStatus = "FullyReceived";
//           else if (anyReceived) po.orderStatus = "PartiallyReceived";
//           else po.orderStatus = "Open";
//           await po.save({ session });
//         }
//       }

//       await session.commitTransaction();
//       session.endSession();

//       // Success – exit retry loop
//       // Optional accounting (outside transaction)
//       try {
//         const totalAmount = grnData.grandTotal || grnData.items.reduce((sum, item) => sum + (item.quantity * item.unitPrice), 0);
//         if (totalAmount > 0 && typeof autoGRN === 'function') {
//           await autoGRN({
//             companyId,
//             amount: totalAmount,
//             partyId: grnData.supplier,
//             partyName: grnData.supplierName,
//             referenceId: grn._id,
//             referenceNumber: grn.documentNumberGrn,
//             narration: `GRN ${grn.documentNumberGrn} — Stock received`,
//             date: grnData.postingDate || new Date(),
//             createdBy: decoded.id || decoded.userId,
//           });
//         }
//       } catch (accountingErr) {
//         console.error(`Accounting entry failed for GRN ${grn.documentNumberGrn}:`, accountingErr.message);
//       }

//       return NextResponse.json(
//         { success: true, message: "GRN created successfully", data: grn },
//         { status: 201 }
//       );
//     } catch (error) {
//       await session.abortTransaction();
//       session.endSession();
//       attempt++;
//       console.error(`Transaction attempt ${attempt} failed:`, error);
//       if (attempt === maxAttempts) {
//         // All retries exhausted
//         return NextResponse.json({ success: false, error: error.message }, { status: 500 });
//       }
//       // Wait before retrying (exponential backoff)
//       await new Promise(resolve => setTimeout(resolve, attempt * 100));
//     }
//   }
// }

// // ──────────────────────────────────────────────────────────────
// // PUT /api/grn – Update GRN (no stock changes)
// // ──────────────────────────────────────────────────────────────
// export async function PUT(req) {
//   const session = await mongoose.startSession();
//   session.startTransaction();
//   try {
//     await dbConnect();
//     const token = getTokenFromHeader(req);
//     if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
//     const decoded = verifyJWT(token);
//     if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid token" }, { status: 401 });

//     const { fields, files } = await parseForm(req);
//     const grnData = JSON.parse(fields.grnData || "{}");
//     const removedFiles = JSON.parse(fields.removedFiles || "[]");
//     const existingFiles = JSON.parse(fields.existingFiles || "[]");

//     if (!grnData._id) return NextResponse.json({ success: false, error: "GRN ID required" }, { status: 400 });
//     if (!Array.isArray(grnData.items) || grnData.items.length === 0) {
//       return NextResponse.json({ success: false, error: "At least one item required" }, { status: 400 });
//     }

//     // Validate IDs
//     for (let i = 0; i < grnData.items.length; i++) {
//       const item = grnData.items[i];
//       if (!Types.ObjectId.isValid(item.item)) throw new Error(`Invalid item ID for row ${i + 1}`);
//       if (!Types.ObjectId.isValid(item.warehouse)) throw new Error(`Invalid warehouse ID for row ${i + 1}`);
//     }

//     const newFiles = await uploadFiles(files.newAttachments || [], "grn-attachments", decoded.companyId);
//     grnData.attachments = [...existingFiles, ...newFiles];
//     for (const file of removedFiles) {
//       if (file.publicId) await cloudinary.uploader.destroy(file.publicId);
//     }

//     const updatedGRN = await GRN.findByIdAndUpdate(grnData._id, grnData, { new: true, session });
//     if (!updatedGRN) return NextResponse.json({ success: false, error: "GRN not found" }, { status: 404 });

//     await session.commitTransaction();
//     session.endSession();

//     return NextResponse.json({ success: true, message: "GRN updated successfully", data: updatedGRN }, { status: 200 });
//   } catch (error) {
//     await session.abortTransaction();
//     session.endSession();
//     console.error("PUT /api/grn error:", error);
//     return NextResponse.json({ success: false, error: error.message }, { status: 500 });
//   }
// }

// // ──────────────────────────────────────────────────────────────
// // GET /api/grn – List or single GRN
// // ──────────────────────────────────────────────────────────────
// export async function GET(req) {
//   try {
//     await dbConnect();
//     const token = getTokenFromHeader(req);
//     if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
//     const decoded = verifyJWT(token);
//     if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid token" }, { status: 401 });

//     const { searchParams } = new URL(req.url);
//     const id = searchParams.get("id");
//     const companyId = decoded.companyId;

//     if (id) {
//       const grn = await GRN.findOne({ _id: id, companyId })
//         .populate("supplier", "supplierCode supplierName")
//         .populate("items.item", " itemCode itemName imageUrl  variants gstRate");
//       if (!grn) return NextResponse.json({ success: false, error: "GRN not found" }, { status: 404 });
//       return NextResponse.json({ success: true, data: grn }, { status: 200 });
//     }

//     const page = parseInt(searchParams.get("page")) || 1;
//     const limit = parseInt(searchParams.get("limit")) || 10;
//     const skip = (page - 1) * limit;

//     const [grns, total] = await Promise.all([
//       GRN.find({ companyId })
//         .populate("supplier", "supplierCode supplierName")
//         .populate("items.item", "itemCode itemName imageUrl  variants gstRate")
//         .sort({ createdAt: -1 })
//         .skip(skip)
//         .limit(limit),
//       GRN.countDocuments({ companyId }),
//     ]);

//     return NextResponse.json({
//       success: true,
//       data: grns,
//       pagination: { page, limit, total, pages: Math.ceil(total / limit) },
//     });
//   } catch (error) {
//     console.error("GET /api/grn error:", error);
//     return NextResponse.json({ success: false, error: error.message }, { status: 500 });
//   }
// }

// // ──────────────────────────────────────────────────────────────
// // DELETE /api/grn – Delete GRN and revert inventory changes
// // ──────────────────────────────────────────────────────────────
// export async function DELETE(req) {
//   const session = await mongoose.startSession();
//   session.startTransaction();

//   try {
//     await dbConnect();
//     const token = getTokenFromHeader(req);
//     if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
//     const decoded = verifyJWT(token);
//     if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid token" }, { status: 401 });

//     const { searchParams } = new URL(req.url);
//     const id = searchParams.get("id");
//     if (!id || !Types.ObjectId.isValid(id)) {
//       return NextResponse.json({ success: false, error: "Invalid GRN ID" }, { status: 400 });
//     }

//     // Find the GRN
//     const grn = await GRN.findOne({ _id: id, companyId: decoded.companyId }).session(session);
//     if (!grn) {
//       return NextResponse.json({ success: false, error: "GRN not found" }, { status: 404 });
//     }

//     const fromPO = !!grn.purchaseOrderId;

//     // ✅ Reverse inventory changes for each item (remove stock, restore onOrder)
//     for (const item of grn.items) {
//       await processGrnItem(item, grn._id, decoded, session, fromPO, true);
//     }

//     // ✅ Update the linked Purchase Order (reduce received quantities)
//     if (fromPO && grn.purchaseOrderId) {
//       const po = await PurchaseOrder.findById(grn.purchaseOrderId).session(session);
//       if (po) {
//         for (const grnItem of grn.items) {
//           const poItem = po.items.find(pi => pi.item.toString() === (grnItem.item?._id || grnItem.item));
//           if (poItem) {
//             const prevReceived = poItem.receivedQuantity || 0;
//             poItem.receivedQuantity = Math.max(prevReceived - grnItem.quantity, 0);
//           }
//         }
//         // Re‑evaluate PO status
//         const fullyReceived = po.items.every(pi => (pi.receivedQuantity || 0) >= (pi.quantity || 0));
//         const anyReceived = po.items.some(pi => (pi.receivedQuantity || 0) > 0);
//         if (fullyReceived) po.orderStatus = "FullyReceived";
//         else if (anyReceived) po.orderStatus = "PartiallyReceived";
//         else po.orderStatus = "Open";
//         await po.save({ session });
//       }
//     }

//     // Delete attached files from Cloudinary
//     if (grn.attachments && grn.attachments.length) {
//       const publicIds = grn.attachments.map(a => a.publicId).filter(Boolean);
//       await deleteFilesByPublicIds(publicIds);
//     }

//     // Delete the GRN document
//     await GRN.deleteOne({ _id: id, companyId: decoded.companyId }).session(session);

//     await session.commitTransaction();
//     session.endSession();

//     return NextResponse.json({ success: true, message: "GRN deleted successfully" }, { status: 200 });
//   } catch (error) {
//     await session.abortTransaction();
//     session.endSession();
//     console.error("DELETE /api/grn error:", error);
//     return NextResponse.json({ success: false, error: error.message }, { status: 500 });
//   }
// }

