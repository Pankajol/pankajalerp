import { NextResponse } from "next/server";
import mongoose from "mongoose";
import dbConnect from "@/lib/db";
import PurchaseOrder from "@/models/PurchaseOrder";
import SalesOrder from "@/models/SalesOrder";
import PurchaseQuotation from "@/models/PurchaseQuotationModel";
import Inventory from "@/models/Inventory";
import Supplier from "@/models/SupplierModels";
import ItemModels from "@/models/ItemModels";
import StockMovement from "@/models/StockMovement";
import { getTokenFromHeader, verifyJWT } from "@/lib/auth";
import { v2 as cloudinary } from "cloudinary";
import Counter from "@/models/Counter";

export const config = { api: { bodyParser: false } };

cloudinary.config({
  cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
  api_key: process.env.CLOUDINARY_API_KEY,
  api_secret: process.env.CLOUDINARY_API_SECRET,
});

// ── Helper: extract a clean string ID from any format ──
function normalizeId(value) {
  if (!value) return null;
  if (typeof value === 'string') return value;
  if (value instanceof mongoose.Types.ObjectId) return value.toString();
  if (value._id) return normalizeId(value._id);
  if (value.$oid) return value.$oid;  // MongoDB extended JSON
  if (value.toString) return value.toString();
  return null;
}

// ──────────────────────────────────────────────────────────────────────────────
// HELPER: Update Inventory onOrder (add or remove) + StockMovement
// ──────────────────────────────────────────────────────────────────────────────
async function updateInventoryForOrder(order, decoded, action, session = null) {
  const factor = action === "add" ? 1 : -1;
  const errors = [];
  const options = session ? { session } : {};

  for (const [index, item] of order.items.entries()) {
    try {
      if (!item.item || !item.quantity) {
        throw new Error(`Item ${index + 1}: missing item ID or quantity`);
      }

      // ── Normalize IDs ──
      const itemIdStr = normalizeId(item.item);
      const warehouseIdStr = normalizeId(item.warehouse);
      if (!itemIdStr || !warehouseIdStr) {
        throw new Error(`Item ${index + 1}: invalid item or warehouse ID`);
      }

      let variantIdStr = null;
      // Try to get variantId from multiple places
      if (item.variant) {
        if (typeof item.variant === 'string') variantIdStr = item.variant;
        else if (typeof item.variant === 'object') {
          variantIdStr = normalizeId(item.variant.variantId) ||
                         normalizeId(item.variant._id) ||
                         normalizeId(item.variant.id);
        }
      }
      if (!variantIdStr && item.selectedVariantId) variantIdStr = normalizeId(item.selectedVariantId);
      if (!variantIdStr && item.variantId) variantIdStr = normalizeId(item.variantId);

      // ── Convert to ObjectId for DB queries ──
      const itemId = new mongoose.Types.ObjectId(itemIdStr);
      const warehouseId = new mongoose.Types.ObjectId(warehouseIdStr);
      let variantId = variantIdStr ? new mongoose.Types.ObjectId(variantIdStr) : null;

      // ── Fetch full item with variants ──
      const fullItem = await ItemModels.findById(itemId).select('variants').lean().session(session);
      if (!fullItem) {
        throw new Error(`Item ${index + 1}: item not found (ID: ${itemIdStr})`);
      }

      const itemHasVariants = fullItem.variants && fullItem.variants.length > 0;

      if (itemHasVariants) {
        // If variantId still missing, try to match by SKU
        if (!variantId && item.itemCode) {
          const matched = fullItem.variants.find(v => v.sku === item.itemCode);
          if (matched) variantId = matched._id;
        }
        if (!variantId) {
          const availableSkus = fullItem.variants.map(v => v.sku).join(', ');
          throw new Error(
            `Item ${index + 1} (${item.itemName || item.itemCode}): ` +
            `Variant ID required. Available SKUs: ${availableSkus || 'none'}`
          );
        }
        // Verify variant belongs to item
        const validVariant = fullItem.variants.some(v => v._id.toString() === variantId.toString());
        if (!validVariant) {
          throw new Error(
            `Item ${index + 1}: Variant ${variantId} does not belong to "${item.itemName || item.item}"`
          );
        }
      } else {
        // No variants – ignore variantId
        if (variantId) {
          console.warn(`Item ${index + 1}: variant provided but item has no variants – ignoring.`);
          variantId = null;
        }
      }

      const quantityToApply = item.quantity * factor;

      // ── Find or create inventory ──
      let inventory = await Inventory.findOne({
        companyId: decoded.companyId,
        item: itemId,
        warehouse: warehouseId,
      }, null, options);

      if (!inventory) {
        if (action === "remove") {
          console.warn(`Item ${index + 1}: no inventory to remove, skipping.`);
          continue;
        }
        inventory = new Inventory({
          companyId: decoded.companyId,
          item: itemId,
          warehouse: warehouseId,
          hasVariants: !!variantId,
        });
        if (!variantId) {
          inventory.onOrder = 0;
        }
        await inventory.save(options);
      }

      // ── Update onOrder ──
      if (variantId) {
        // Switch to variant mode
        inventory.hasVariants = true;
        inventory.quantity = 0;
        inventory.committed = 0;
        inventory.onOrder = 0;

        const variantObjId = new mongoose.Types.ObjectId(variantId);
        let variantInv = inventory.variantInventory.find(
          v => v.variantId.toString() === variantObjId.toString()
        );

        if (!variantInv) {
          if (action === "remove") continue;
          // Create new variant inventory entry
          const matchedVariant = fullItem.variants.find(
            v => v._id.toString() === variantObjId.toString()
          );
          const sku = matchedVariant?.sku || `Variant-${variantObjId.toString().slice(-6)}`;
          const attributes = matchedVariant?.attributes || {};
          variantInv = {
            variantId: variantObjId,
            sku,
            attributes,
            quantity: 0,
            committed: 0,
            onOrder: 0,
            batches: []
          };
          inventory.variantInventory.push(variantInv);
        }

        // Update onOrder for this variant
        variantInv.onOrder = Math.max(0, (variantInv.onOrder || 0) + quantityToApply);
        await inventory.save(options);
      } else {
        // Non‑variant
        inventory.onOrder = Math.max(0, (inventory.onOrder || 0) + quantityToApply);
        await inventory.save(options);
      }

      // ── Update stock status (if method exists) ──
      if (typeof inventory.updateStockStatus === 'function') {
        await inventory.updateStockStatus();
      }

      // ── StockMovement ──
      if (action === "add") {
        await StockMovement.create([{
          companyId: decoded.companyId,
          createdBy: decoded.id,
          item: itemId,
          variantId: variantId ? new mongoose.Types.ObjectId(variantId) : null,
          warehouse: warehouseId,
          movementType: "ON_ORDER",
          quantity: item.quantity,
          reference: order._id,
          referenceModel: "PurchaseOrder",
          remarks: `Stock ordered via PO ${order.documentNumberPurchaseOrder}`,
          date: new Date()
        }], options);
      } else {
        await StockMovement.deleteMany({
          companyId: decoded.companyId,
          reference: order._id,
          referenceModel: "PurchaseOrder"
        }, options);
      }

      console.log(`✅ Item ${index + 1} (${item.itemCode || item.itemName}) processed successfully.`);
    } catch (err) {
      errors.push(`Item ${index + 1}: ${err.message}`);
    }
  }

  if (errors.length > 0) {
    throw new Error(`Inventory update failed for ${errors.length} item(s):\n${errors.join('\n')}`);
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// POST – Create Purchase Order (with transaction)
// ──────────────────────────────────────────────────────────────────────────────
export async function POST(req) {
  await dbConnect();

  const token = getTokenFromHeader(req);
  if (!token) {
    return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
  }
  const decoded = verifyJWT(token);
  if (!decoded?.companyId) {
    return NextResponse.json({ success: false, error: "Invalid company ID" }, { status: 401 });
  }

  const formData = await req.formData();
  const rawData = formData.get("orderData");
  if (!rawData) {
    return NextResponse.json({ success: false, error: "Missing order data" }, { status: 400 });
  }

  let orderData;
  try {
    orderData = JSON.parse(rawData);
  } catch (err) {
    return NextResponse.json({ success: false, error: "Invalid JSON in orderData" }, { status: 400 });
  }

  // Clean and set required fields
  delete orderData._id;
  orderData.companyId = decoded.companyId;
  orderData.createdBy = decoded.id;
  orderData.orderStatus = orderData.orderStatus || "Open";

  // ── File upload handling ──
  const files = formData.getAll("attachments");
  const uploadedFiles = [];
  for (const file of files) {
    if (file && file.size > 0) {
      try {
        const buffer = await file.arrayBuffer();
        const uploadRes = await new Promise((resolve, reject) => {
          const stream = cloudinary.uploader.upload_stream(
            { folder: "purchase-orders", resource_type: "auto" },
            (err, result) => (err ? reject(err) : resolve(result))
          );
          stream.end(Buffer.from(buffer));
        });
        uploadedFiles.push({
          fileName: file.name,
          fileType: file.type,
          fileUrl: uploadRes.secure_url,
          cloudinaryId: uploadRes.public_id,
          uploadedAt: new Date(),
        });
      } catch (uploadErr) {
        console.error("File upload error:", uploadErr);
      }
    }
  }

  const existingFiles = orderData.existingFiles || [];
  const removedFiles = orderData.removedFiles || [];
  orderData.attachments = [
    ...existingFiles.filter((f) => !removedFiles.some((r) => r.cloudinaryId === f.cloudinaryId)),
    ...uploadedFiles,
  ];
  delete orderData.existingFiles;
  delete orderData.removedFiles;

  // ── Validate warehouses ──
  if (orderData.items.some(item => !item.warehouse)) {
    return NextResponse.json({
      success: false,
      error: "All items must have a warehouse assigned"
    }, { status: 422 });
  }

  // ── Link to Purchase Quotation ──
  let quotationId = null;
  if (orderData.sourcePurchaseQuotationId || orderData.purchasequotation) {
    const pqId = orderData.sourcePurchaseQuotationId || orderData.purchasequotation;
    const pq = await PurchaseQuotation.findById(pqId);
    if (pq) {
      orderData.supplier = orderData.supplier || pq.supplier;
      if (!orderData.items || orderData.items.length === 0) {
        orderData.items = pq.items;
      }
      // Check remaining quantities
      const qtyErrors = [];
      for (const poItem of orderData.items) {
        const pqItem = pq.items.find(item => {
          const sameItem = item.item?.toString() === poItem.item?.toString();
          const pqVariant = item.variant?.variantId?.toString() || "";
          const poVariant = poItem.variant?.variantId?.toString() ||
                            poItem.selectedVariantId?.toString() || "";
          return sameItem && pqVariant === poVariant;
        });
        if (!pqItem) continue;

        const quotationQty = Number(pqItem.quantity || 0);
        const orderedQty = Number(pqItem.orderedQuantity || 0);
        const remainingQty = quotationQty - orderedQty;
        const requestedQty = Number(poItem.quantity || 0);

        if (requestedQty > remainingQty) {
          qtyErrors.push(
            `${pqItem.itemName || pqItem.itemCode} (Remaining: ${remainingQty}, Requested: ${requestedQty})`
          );
        }
      }
      if (qtyErrors.length > 0) {
        return NextResponse.json(
          {
            success: false,
            error: "Only remaining quantity can be copied to PO. " + qtyErrors.join(" | ")
          },
          { status: 400 }
        );
      }
      quotationId = pq._id;
      orderData._purchaseQuotationId = pq._id;
    }
  }

  // ── Generate document number ──
  const now = new Date();
  const currentYear = now.getFullYear();
  const currentMonth = now.getMonth() + 1;
  let fyStart = currentYear, fyEnd = currentYear + 1;
  if (currentMonth < 4) {
    fyStart = currentYear - 1;
    fyEnd = currentYear;
  }
  const financialYear = `${fyStart}-${String(fyEnd).slice(-2)}`;
  const key = `PurchaseOrder_${decoded.companyId}`;

  let counter, retries = 3;
  while (retries > 0) {
    try {
      counter = await Counter.findOneAndUpdate(
        { id: key, companyId: decoded.companyId },
        { $inc: { seq: 1 } },
        { new: true, upsert: true }
      );
      break;
    } catch (err) {
      retries--;
      if (retries === 0) throw err;
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }
  const paddedSeq = String(counter.seq).padStart(5, "0");
  const documentNumberPurchaseOrder = `PURCH-ORD/${financialYear}/${paddedSeq}`;
  orderData.documentNumberPurchaseOrder = documentNumberPurchaseOrder;
  delete orderData._purchaseQuotationId;

  // ── Use a transaction ──
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    // Create Purchase Order
    const [createdOrder] = await PurchaseOrder.create([orderData], { session });

    // ── Update Purchase Quotation ──
    if (quotationId) {
      const pq = await PurchaseQuotation.findById(quotationId).session(session);
      if (pq) {
        for (const poItem of createdOrder.items) {
          const pqItem = pq.items.find(item => {
            const sameItem = item.item?.toString() === poItem.item?.toString();
            const pqVariant = item.variant?.variantId?.toString() || "";
            const poVariant = poItem.variant?.variantId?.toString() ||
                              poItem.selectedVariantId?.toString() || "";
            return sameItem && pqVariant === poVariant;
          });
          if (!pqItem) continue;
          pqItem.orderedQuantity =
            Number(pqItem.orderedQuantity || 0) + Number(poItem.quantity || 0);
          if (pqItem.orderedQuantity > pqItem.quantity) {
            pqItem.orderedQuantity = pqItem.quantity;
          }
        }
        const allOrdered = pq.items.every(
          item => Number(item.orderedQuantity || 0) >= Number(item.quantity || 0)
        );
        const partiallyOrdered = pq.items.some(
          item => Number(item.orderedQuantity || 0) > 0
        );
        if (allOrdered) pq.status = "FullyOrdered";
        else if (partiallyOrdered) pq.status = "PartiallyOrdered";
        else pq.status = "Open";
        await pq.save({ session });
      }
    }

    // ── Update linked Sales Orders ──
    if (Array.isArray(orderData.salesOrder) && orderData.salesOrder.length > 0) {
      await SalesOrder.updateMany(
        { _id: { $in: orderData.salesOrder }, companyId: decoded.companyId },
        { $set: { linkedPurchaseOrder: createdOrder._id, status: "LinkedToPurchaseOrder" } },
        { session }
      );
    }

    // ── Update Inventory (with the same session) ──
    await updateInventoryForOrder(createdOrder, decoded, "add", session);

    // Commit transaction
    await session.commitTransaction();
    session.endSession();

    // ── Return populated order ──
    const populatedOrder = await PurchaseOrder.findById(createdOrder._id)
      .populate("supplier", "supplierName supplierCode contactPerson")
      .populate("items.item", "itemCode itemName unitPrice imageUrl variants");

    return NextResponse.json(
      { success: true, message: "Purchase Order created successfully", data: populatedOrder },
      { status: 201 }
    );
  } catch (error) {
    await session.abortTransaction();
    session.endSession();
    console.error("Transaction error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}


// ──────────────────────────────────────────────────────────────────────────────
// GET – Fetch Purchase Orders (unchanged)
// ──────────────────────────────────────────────────────────────────────────────
export async function GET(req) {
  try {
    await dbConnect();
    const token = getTokenFromHeader(req);
    if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    const decoded = verifyJWT(token);
    if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid token" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    const status = searchParams.get("status");
    const supplier = searchParams.get("supplier");
    const page = parseInt(searchParams.get("page")) || 1;
    const limit = Math.min(parseInt(searchParams.get("limit")) || 10, 100);
    const search = searchParams.get("search") || "";

    if (id) {
      if (!mongoose.Types.ObjectId.isValid(id)) {
        return NextResponse.json({ success: false, error: "Invalid ID" }, { status: 400 });
      }
      const order = await PurchaseOrder.findOne({ _id: id, companyId: decoded.companyId })
        .populate("supplier", "supplierName supplierCode contactPerson")
        .populate("items.item", "itemCode itemName unitPrice imageUrl variants");
      if (!order) return NextResponse.json({ success: false, error: "Order not found" }, { status: 404 });
      return NextResponse.json({ success: true, data: order });
    }

    const query = { companyId: decoded.companyId };
    if (status) query.orderStatus = status;
    if (supplier && mongoose.Types.ObjectId.isValid(supplier)) query.supplier = supplier;
    if (search) {
      query.$or = [
        { documentNumberPurchaseOrder: { $regex: search, $options: "i" } },
        { supplierName: { $regex: search, $options: "i" } },
        { refNumber: { $regex: search, $options: "i" } }
      ];
    }

    const skip = (page - 1) * limit;
    const [orders, total] = await Promise.all([
      PurchaseOrder.find(query)
        .populate("supplier", "supplierName supplierCode contactPerson emailId mobileNumber contactNumber phone supplierType supplierGroup valid glAccount")
        .populate("items.item", "itemCode itemName unitPrice imageUrl")
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .lean(),
      PurchaseOrder.countDocuments(query)
    ]);

    return NextResponse.json({
      success: true,
      data: orders,
      pagination: { page, limit, total, pages: Math.ceil(total / limit) }
    });
  } catch (error) {
    console.error("GET /api/purchase-order error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// PUT – Update Purchase Order (with transaction)
// ──────────────────────────────────────────────────────────────────────────────
export async function PUT(req) {
  try {
    await dbConnect();
    const token = getTokenFromHeader(req);
    if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    const decoded = verifyJWT(token);
    if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid company ID" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id || !mongoose.Types.ObjectId.isValid(id)) {
      return NextResponse.json({ success: false, error: "Valid ID required" }, { status: 400 });
    }

    const formData = await req.formData();
    const rawData = formData.get("orderData");
    let orderData;
    try {
      orderData = JSON.parse(rawData);
    } catch (err) {
      return NextResponse.json({ success: false, error: "Invalid JSON in orderData" }, { status: 400 });
    }

    // ── File handling ──
    const files = formData.getAll("attachments");
    const uploadedFiles = [];
    for (const file of files) {
      if (file && file.size > 0) {
        const buffer = await file.arrayBuffer();
        const uploadRes = await new Promise((resolve, reject) => {
          const stream = cloudinary.uploader.upload_stream(
            { folder: "purchase-orders", resource_type: "auto" },
            (err, result) => (err ? reject(err) : resolve(result))
          );
          stream.end(Buffer.from(buffer));
        });
        uploadedFiles.push({
          fileName: file.name,
          fileType: file.type,
          fileUrl: uploadRes.secure_url,
          cloudinaryId: uploadRes.public_id,
          uploadedAt: new Date(),
        });
      }
    }

    const existingFiles = orderData.existingFiles || [];
    const removedFiles = orderData.removedFiles || [];
    for (const file of removedFiles) {
      if (file.cloudinaryId) await cloudinary.uploader.destroy(file.cloudinaryId).catch(e => console.warn(e));
    }
    orderData.attachments = [
      ...existingFiles.filter(f => !removedFiles.some(r => r.cloudinaryId === f.cloudinaryId)),
      ...uploadedFiles,
    ];
    delete orderData.existingFiles;
    delete orderData.removedFiles;
    delete orderData._id;

    // ── Use transaction ──
    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      // Get existing order
      const existingOrder = await PurchaseOrder.findOne({ _id: id, companyId: decoded.companyId }).session(session);
      if (!existingOrder) {
        throw new Error("Order not found");
      }

      // Reverse old inventory
      await updateInventoryForOrder(existingOrder, decoded, "remove", session);

      // Update the order
      const updatedOrder = await PurchaseOrder.findOneAndUpdate(
        { _id: id, companyId: decoded.companyId },
        { ...orderData, updatedAt: new Date() },
        { new: true, runValidators: true, session }
      ).populate("supplier", "supplierName supplierCode contactPerson")
        .populate("items.item", "itemCode itemName unitPrice imageUrl variants");

      // Apply new inventory
      await updateInventoryForOrder(updatedOrder, decoded, "add", session);

      // Adjust quotation orderedQuantity if linked
      if (existingOrder._purchaseQuotationId) {
        const pq = await PurchaseQuotation.findById(existingOrder._purchaseQuotationId).session(session);
        if (pq) {
          // Subtract old quantities
          for (const oldItem of existingOrder.items) {
            const pqItem = pq.items.find(item => {
              const sameItem = item.item?.toString() === oldItem.item?.toString();
              const pqVariant = item.variant?.variantId?.toString() || "";
              const oldVariant = oldItem.variant?.variantId?.toString() ||
                                 oldItem.selectedVariantId?.toString() || "";
              return sameItem && pqVariant === oldVariant;
            });
            if (pqItem) {
              pqItem.orderedQuantity = Math.max(0, (pqItem.orderedQuantity || 0) - oldItem.quantity);
            }
          }
          // Add new quantities
          for (const newItem of updatedOrder.items) {
            const pqItem = pq.items.find(item => {
              const sameItem = item.item?.toString() === newItem.item?.toString();
              const pqVariant = item.variant?.variantId?.toString() || "";
              const newVariant = newItem.variant?.variantId?.toString() ||
                                 newItem.selectedVariantId?.toString() || "";
              return sameItem && pqVariant === newVariant;
            });
            if (pqItem) {
              pqItem.orderedQuantity = (pqItem.orderedQuantity || 0) + newItem.quantity;
              if (pqItem.orderedQuantity > pqItem.quantity) {
                pqItem.orderedQuantity = pqItem.quantity;
              }
            }
          }
          // Recalculate status
          const allOrdered = pq.items.every(
            item => Number(item.orderedQuantity || 0) >= Number(item.quantity || 0)
          );
          const partiallyOrdered = pq.items.some(
            item => Number(item.orderedQuantity || 0) > 0
          );
          if (allOrdered) pq.status = "FullyOrdered";
          else if (partiallyOrdered) pq.status = "PartiallyOrdered";
          else pq.status = "Open";
          await pq.save({ session });
        }
      }

      await session.commitTransaction();
      session.endSession();
      return NextResponse.json({ success: true, message: "Purchase Order updated successfully", data: updatedOrder });
    } catch (error) {
      await session.abortTransaction();
      session.endSession();
      throw error;
    }
  } catch (error) {
    console.error("PUT /api/purchase-order error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}

// ──────────────────────────────────────────────────────────────────────────────
// DELETE – Delete Purchase Order (with transaction)
// ──────────────────────────────────────────────────────────────────────────────
export async function DELETE(req) {
  try {
    await dbConnect();
    const token = getTokenFromHeader(req);
    if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
    const decoded = verifyJWT(token);
    if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid token" }, { status: 401 });

    const { searchParams } = new URL(req.url);
    const id = searchParams.get("id");
    if (!id || !mongoose.Types.ObjectId.isValid(id)) {
      return NextResponse.json({ success: false, error: "Valid ID required" }, { status: 400 });
    }

    const session = await mongoose.startSession();
    session.startTransaction();

    try {
      const order = await PurchaseOrder.findOne({ _id: id, companyId: decoded.companyId }).session(session);
      if (!order) {
        throw new Error("Order not found");
      }

      // ── Delete Cloudinary attachments ──
      if (order.attachments?.length) {
        for (const file of order.attachments) {
          if (file.cloudinaryId) await cloudinary.uploader.destroy(file.cloudinaryId).catch(e => console.warn(e));
        }
      }

      // ── Reverse inventory ──
      await updateInventoryForOrder(order, decoded, "remove", session);

      // ── Adjust quotation orderedQuantity ──
      if (order._purchaseQuotationId) {
        const pq = await PurchaseQuotation.findById(order._purchaseQuotationId).session(session);
        if (pq) {
          for (const poItem of order.items) {
            const pqItem = pq.items.find(item => {
              const sameItem = item.item?.toString() === poItem.item?.toString();
              const pqVariant = item.variant?.variantId?.toString() || "";
              const poVariant = poItem.variant?.variantId?.toString() ||
                                poItem.selectedVariantId?.toString() || "";
              return sameItem && pqVariant === poVariant;
            });
            if (pqItem) {
              pqItem.orderedQuantity = Math.max(0, (pqItem.orderedQuantity || 0) - poItem.quantity);
            }
          }
          const allOrdered = pq.items.every(
            item => Number(item.orderedQuantity || 0) >= Number(item.quantity || 0)
          );
          const partiallyOrdered = pq.items.some(
            item => Number(item.orderedQuantity || 0) > 0
          );
          if (allOrdered) pq.status = "FullyOrdered";
          else if (partiallyOrdered) pq.status = "PartiallyOrdered";
          else pq.status = "Open";
          await pq.save({ session });
        }
      }

      // ── Delete the order ──
      await PurchaseOrder.deleteOne({ _id: id, companyId: decoded.companyId }).session(session);

      await session.commitTransaction();
      session.endSession();

      return NextResponse.json({ success: true, message: "Purchase Order deleted successfully" });
    } catch (error) {
      await session.abortTransaction();
      session.endSession();
      throw error;
    }
  } catch (error) {
    console.error("DELETE /api/purchase-order error:", error);
    return NextResponse.json({ success: false, error: error.message }, { status: 500 });
  }
}



// import { NextResponse } from "next/server";
// import mongoose from "mongoose";
// import dbConnect from "@/lib/db";
// import PurchaseOrder from "@/models/PurchaseOrder";
// import SalesOrder from "@/models/SalesOrder";
// import PurchaseQuotation from "@/models/PurchaseQuotationModel";
// import Inventory from "@/models/Inventory";
// import StockMovement from "@/models/StockMovement";
// import { getTokenFromHeader, verifyJWT } from "@/lib/auth";
// import { v2 as cloudinary } from "cloudinary";
// import Counter from "@/models/Counter";
// import Supplier from "@/models/SupplierModels";
// import ItemModels from "@/models/ItemModels";


// export const config = { api: { bodyParser: false } };

// cloudinary.config({
//   cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
//   api_key: process.env.CLOUDINARY_API_KEY,
//   api_secret: process.env.CLOUDINARY_API_SECRET,
// });

// // ✅ POST - Create Purchase Order
// export async function POST(req) {
//   await dbConnect();
  
//   try {
//     const token = getTokenFromHeader(req);
//     if (!token) {
//       return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
//     }

//     const decoded = verifyJWT(token);
//     if (!decoded?.companyId) {
//       return NextResponse.json({ success: false, error: "Invalid company ID" }, { status: 401 });
//     }

//     const formData = await req.formData();
//     const rawData = formData.get("orderData");
//     if (!rawData) {
//       return NextResponse.json({ success: false, error: "Missing order data" }, { status: 400 });
//     }

//     let orderData;
//     try {
//       orderData = JSON.parse(rawData);
//     } catch (err) {
//       return NextResponse.json({ success: false, error: "Invalid JSON in orderData" }, { status: 400 });
//     }

//     // Clean + add required fields
//     delete orderData._id;
//     orderData.companyId = decoded.companyId;
//     orderData.createdBy = decoded.id;
//     orderData.orderStatus = orderData.orderStatus || "Open";

//     // Handle file uploads
//     const files = formData.getAll("attachments");
//     const uploadedFiles = [];
//     for (const file of files) {
//       if (file && file.size > 0) {
//         try {
//           const buffer = await file.arrayBuffer();
//           const uploadRes = await new Promise((resolve, reject) => {
//             const stream = cloudinary.uploader.upload_stream(
//               { folder: "purchase-orders", resource_type: "auto" },
//               (err, result) => (err ? reject(err) : resolve(result))
//             );
//             stream.end(Buffer.from(buffer));
//           });
//           uploadedFiles.push({
//             fileName: file.name,
//             fileType: file.type,
//             fileUrl: uploadRes.secure_url,
//             cloudinaryId: uploadRes.public_id,
//             uploadedAt: new Date(),
//           });
//         } catch (uploadErr) {
//           console.error("File upload error:", uploadErr);
//         }
//       }
//     }

//     const existingFiles = orderData.existingFiles || [];
//     const removedFiles = orderData.removedFiles || [];
//     orderData.attachments = [
//       ...existingFiles.filter((f) => !removedFiles.some((r) => r.cloudinaryId === f.cloudinaryId)),
//       ...uploadedFiles,
//     ];
//     delete orderData.existingFiles;
//     delete orderData.removedFiles;

//     // Validate items have warehouse
//     if (orderData.items.some(item => !item.warehouse)) {
//       return NextResponse.json({ 
//         success: false, 
//         error: "All items must have a warehouse assigned" 
//       }, { status: 422 });
//     }

//     // Link to Purchase Quotation if provided
// // Link to Purchase Quotation if provided
// if (orderData.sourcePurchaseQuotationId || orderData.purchasequotation) {

//   const pqId =
//     orderData.sourcePurchaseQuotationId ||
//     orderData.purchasequotation;

//   const pq = await PurchaseQuotation.findById(pqId);

//   if (pq) {

//     orderData.supplier = orderData.supplier || pq.supplier;

//     if (!orderData.items || orderData.items.length === 0) {
//       orderData.items = pq.items;
//     }

//     const qtyErrors = [];

//     for (const poItem of orderData.items) {

//       const pqItem = pq.items.find(item => {

//         const sameItem =
//           item.item?.toString() === poItem.item?.toString();

//         const pqVariant =
//           item.variant?.variantId?.toString() || "";

//         const poVariant =
//           poItem.variant?.variantId?.toString() ||
//           poItem.selectedVariantId?.toString() ||
//           "";

//         return sameItem && pqVariant === poVariant;
//       });

//       if (!pqItem) continue;

//       const quotationQty = Number(pqItem.quantity || 0);
//       const orderedQty = Number(pqItem.orderedQuantity || 0);
//       const remainingQty = quotationQty - orderedQty;
//       const requestedQty = Number(poItem.quantity || 0);

//       if (requestedQty > remainingQty) {
//         qtyErrors.push(
//           `${pqItem.itemName} (Remaining: ${remainingQty}, Requested: ${requestedQty})`
//         );
//       }
//     }

//     if (qtyErrors.length > 0) {
//       return NextResponse.json(
//         {
//           success: false,
//           error:
//             "Only remaining quantity can be copied to PO. " +
//             qtyErrors.join(" | ")
//         },
//         { status: 400 }
//       );
//     }

//     orderData._purchaseQuotationId = pq._id;
//   }
// }

//     // Generate document number
//     const now = new Date();
//     const currentYear = now.getFullYear();
//     const currentMonth = now.getMonth() + 1;
//     let fyStart = currentYear, fyEnd = currentYear + 1;
//     if (currentMonth < 4) {
//       fyStart = currentYear - 1;
//       fyEnd = currentYear;
//     }
//     const financialYear = `${fyStart}-${String(fyEnd).slice(-2)}`;
//     const key = `PurchaseOrder_${decoded.companyId}`;

//     let counter, retries = 3;
//     while (retries > 0) {
//       try {
//         counter = await Counter.findOneAndUpdate(
//           { id: key, companyId: decoded.companyId },
//           { $inc: { seq: 1 } },
//           { new: true, upsert: true }
//         );
//         break;
//       } catch (err) {
//         retries--;
//         if (retries === 0) throw err;
//         await new Promise(resolve => setTimeout(resolve, 100));
//       }
//     }
//     const paddedSeq = String(counter.seq).padStart(5, "0");
//     const documentNumberPurchaseOrder = `PURCH-ORD/${financialYear}/${paddedSeq}`;
//     orderData.documentNumberPurchaseOrder = documentNumberPurchaseOrder;

//     // Create Purchase Order
//     const purchaseOrder = await PurchaseOrder.create([orderData]);
//     const createdOrder = purchaseOrder[0];

//     // Update linked Sales Orders
//     if (Array.isArray(orderData.salesOrder) && orderData.salesOrder.length > 0) {
//       await SalesOrder.updateMany(
//         { _id: { $in: orderData.salesOrder }, companyId: decoded.companyId },
//         { $set: { linkedPurchaseOrder: createdOrder._id, status: "LinkedToPurchaseOrder" } }
//       );
//     }

//     // ✅ Update Inventory + StockMovement (only increase onOrder, NOT physical stock)
//     for (const item of createdOrder.items) {
//       if (!item.item || !item.quantity) continue;

//       // Find or create inventory record
//       let inventory = await Inventory.findOne({
//         companyId: decoded.companyId,
//         item: item.item,
//         warehouse: item.warehouse
//       });

//       if (!inventory) {
//         inventory = new Inventory({
//           companyId: decoded.companyId,
//           item: item.item,
//           warehouse: item.warehouse,
//           hasVariants: false,
//         });
//         await inventory.save();
//       }

//       const variantId = item.variant?.variantId || item.selectedVariantId;

//       if (variantId) {
//         // Ensure hasVariants flag is true
//         if (!inventory.hasVariants) inventory.hasVariants = true;

//         // Find existing variant inventory or create a placeholder
//         let variantInv = inventory.variantInventory.find(v => v.variantId.toString() === variantId.toString());
//         if (!variantInv) {
//           variantInv = {
//             variantId,
//             sku: item.itemCode,
//             attributes: item.variant?.attributes || {},
//             quantity: 0,       // physical stock remains zero
//             committed: 0,
//             onOrder: 0,
//             batches: []
//           };
//           inventory.variantInventory.push(variantInv);
//         }

//         // 🔹 ONLY increase onOrder – NOT quantity
//         variantInv.onOrder = (variantInv.onOrder || 0) + item.quantity;
//         await inventory.save();
//       } else {
//         // Non‑variant item: only increase onOrder
//         inventory.onOrder = (inventory.onOrder || 0) + item.quantity;
//         await inventory.save();
//       }

//       // Update stock status (based on quantity, not onOrder)
//       await inventory.updateStockStatus();

//       // Create StockMovement entry for ON_ORDER
//       await StockMovement.create({
//         companyId: decoded.companyId,
//         createdBy: decoded.id,
//         item: item.item,
//         variantId: variantId || null,
//         warehouse: item.warehouse,
//         movementType: "ON_ORDER",
//         quantity: item.quantity,
//         reference: createdOrder._id,
//         referenceModel: "PurchaseOrder",
//         remarks: `Stock ordered via PO ${createdOrder.documentNumberPurchaseOrder}`,
//         date: new Date()
//       });
//     }

//     // Populate response
//     const populatedOrder = await PurchaseOrder.findById(createdOrder._id)
//       .populate("supplier", "supplierName supplierCode contactPerson")
//       .populate("items.item", "itemCode itemName unitPrice imageUrl variants");

//     return NextResponse.json(
//       { success: true, message: "Purchase Order created successfully", data: populatedOrder },
//       { status: 201 }
//     );
//   } catch (error) {
//     console.error("Purchase Order Error:", error);
//     return NextResponse.json({ success: false, error: error.message }, { status: 500 });
//   }
// }

// // ✅ GET - Fetch Purchase Orders (supports variants)
// export async function GET(req) {
//   try {
//     await dbConnect();
//     const token = getTokenFromHeader(req);
//     if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
//     const decoded = verifyJWT(token);
//     if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid token" }, { status: 401 });

//     const { searchParams } = new URL(req.url);
//     const id = searchParams.get("id");
//     const status = searchParams.get("status");
//     const supplier = searchParams.get("supplier");
//     const page = parseInt(searchParams.get("page")) || 1;
//     const limit = Math.min(parseInt(searchParams.get("limit")) || 10, 100);
//     const search = searchParams.get("search") || "";

//     if (id) {
//       if (!mongoose.Types.ObjectId.isValid(id)) {
//         return NextResponse.json({ success: false, error: "Invalid ID" }, { status: 400 });
//       }
//       const order = await PurchaseOrder.findOne({ _id: id, companyId: decoded.companyId })
//         .populate("supplier", "supplierName supplierCode contactPerson")
//         .populate("items.item", "itemCode itemName unitPrice imageUrl variants");
//       if (!order) return NextResponse.json({ success: false, error: "Order not found" }, { status: 404 });
//       return NextResponse.json({ success: true, data: order });
//     }

//     const query = { companyId: decoded.companyId };
//     if (status) query.orderStatus = status;
//     if (supplier && mongoose.Types.ObjectId.isValid(supplier)) query.supplier = supplier;
//     if (search) {
//       query.$or = [
//         { documentNumberPurchaseOrder: { $regex: search, $options: "i" } },
//         { supplierName: { $regex: search, $options: "i" } },
//         { refNumber: { $regex: search, $options: "i" } }
//       ];
//     }

//     const skip = (page - 1) * limit;
//     const [orders, total] = await Promise.all([
//       PurchaseOrder.find(query)
//         .populate("supplier", "supplierName supplierCode contactPerson")
//         .populate("items.item", "itemCode itemName unitPrice imageUrl")
//         .sort({ createdAt: -1 })
//         .skip(skip)
//         .limit(limit)
//         .lean(),
//       PurchaseOrder.countDocuments(query)
//     ]);

//     return NextResponse.json({ 
//       success: true, 
//       data: orders,
//       pagination: { page, limit, total, pages: Math.ceil(total / limit) }
//     });
//   } catch (error) {
//     console.error("GET /api/purchase-order error:", error);
//     return NextResponse.json({ success: false, error: error.message }, { status: 500 });
//   }
// }

// // ✅ PUT - Update Purchase Order (supports variants)
// export async function PUT(req) {
//   try {
//     await dbConnect();
//     const token = getTokenFromHeader(req);
//     if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
//     const decoded = verifyJWT(token);
//     if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid company ID" }, { status: 401 });

//     const { searchParams } = new URL(req.url);
//     const id = searchParams.get("id");
//     if (!id || !mongoose.Types.ObjectId.isValid(id)) {
//       return NextResponse.json({ success: false, error: "Valid ID required" }, { status: 400 });
//     }

//     const formData = await req.formData();
//     const rawData = formData.get("orderData");
//     let orderData;
//     try {
//       orderData = JSON.parse(rawData);
//     } catch (err) {
//       return NextResponse.json({ success: false, error: "Invalid JSON in orderData" }, { status: 400 });
//     }

//     // File handling
//     const files = formData.getAll("attachments");
//     const uploadedFiles = [];
//     for (const file of files) {
//       if (file && file.size > 0) {
//         const buffer = await file.arrayBuffer();
//         const uploadRes = await new Promise((resolve, reject) => {
//           const stream = cloudinary.uploader.upload_stream(
//             { folder: "purchase-orders", resource_type: "auto" },
//             (err, result) => (err ? reject(err) : resolve(result))
//           );
//           stream.end(Buffer.from(buffer));
//         });
//         uploadedFiles.push({
//           fileName: file.name,
//           fileType: file.type,
//           fileUrl: uploadRes.secure_url,
//           cloudinaryId: uploadRes.public_id,
//           uploadedAt: new Date(),
//         });
//       }
//     }

//     const existingFiles = orderData.existingFiles || [];
//     const removedFiles = orderData.removedFiles || [];
//     for (const file of removedFiles) {
//       if (file.cloudinaryId) await cloudinary.uploader.destroy(file.cloudinaryId).catch(e => console.warn(e));
//     }
//     orderData.attachments = [
//       ...existingFiles.filter(f => !removedFiles.some(r => r.cloudinaryId === f.cloudinaryId)),
//       ...uploadedFiles,
//     ];
//     delete orderData.existingFiles;
//     delete orderData.removedFiles;
//     delete orderData._id;

//     const updatedOrder = await PurchaseOrder.findOneAndUpdate(
//       { _id: id, companyId: decoded.companyId },
//       { ...orderData, updatedAt: new Date() },
//       { new: true, runValidators: true }
//     ).populate("supplier", "supplierName supplierCode contactPerson")
//       .populate("items.item", "itemCode itemName unitPrice imageUrl variants");

//     if (!updatedOrder) return NextResponse.json({ success: false, error: "Order not found" }, { status: 404 });
//     return NextResponse.json({ success: true, message: "Purchase Order updated successfully", data: updatedOrder });
//   } catch (error) {
//     console.error("PUT /api/purchase-order error:", error);
//     return NextResponse.json({ success: false, error: error.message }, { status: 500 });
//   }
// }

// // ✅ DELETE - Delete Purchase Order
// export async function DELETE(req) {
//   try {
//     await dbConnect();
//     const token = getTokenFromHeader(req);
//     if (!token) return NextResponse.json({ success: false, error: "Unauthorized" }, { status: 401 });
//     const decoded = verifyJWT(token);
//     if (!decoded?.companyId) return NextResponse.json({ success: false, error: "Invalid token" }, { status: 401 });

//     const { searchParams } = new URL(req.url);
//     const id = searchParams.get("id");
//     if (!id || !mongoose.Types.ObjectId.isValid(id)) {
//       return NextResponse.json({ success: false, error: "Valid ID required" }, { status: 400 });
//     }

//     const order = await PurchaseOrder.findOne({ _id: id, companyId: decoded.companyId });
//     if (!order) return NextResponse.json({ success: false, error: "Order not found" }, { status: 404 });

//     if (order.attachments?.length) {
//       for (const file of order.attachments) {
//         if (file.cloudinaryId) await cloudinary.uploader.destroy(file.cloudinaryId).catch(e => console.warn(e));
//       }
//     }
//     await PurchaseOrder.deleteOne({ _id: id, companyId: decoded.companyId });
//     return NextResponse.json({ success: true, message: "Purchase Order deleted successfully" });
//   } catch (error) {
//     console.error("DELETE /api/purchase-order error:", error);
//     return NextResponse.json({ success: false, error: error.message }, { status: 500 });
//   }
// }
