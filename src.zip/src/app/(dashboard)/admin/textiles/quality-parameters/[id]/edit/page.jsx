
"use client";
import { useParams } from "next/navigation";
import QualityParametersForm from "../_components/QualityParametersForm";
export default function EditQualityParameters() {
  const { id } = useParams();
  return <QualityParametersForm id={id} />;
}