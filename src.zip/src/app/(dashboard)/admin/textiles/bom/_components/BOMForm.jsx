// app/admin/textiles/bom/_components/BOMForm.jsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import api from "@/lib/api";
import { toast } from "react-toastify";
import { FaSave, FaTimes, FaPlus, FaTrash } from "react-icons/fa";

export default function BOMForm({ id }) {
  const router = useRouter();
  const isEdit = !!id;
  const [formData, setFormData] = useState({
    bomCode: "",
    product: "",
    shade: "",
    wastePercent: 0,
    batchNo: "",
    components: [],
    status: "draft",
  });
  const [products, setProducts] = useState([]);
  const [shades, setShades] = useState([]);
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(isEdit);
  const [compInput, setCompInput] = useState({
    item: "",
    quantity: 0,
    unit: "",
    wasteFactor: 0,
    notes: "",
  });

  useEffect(() => {
    const loadMasters = async () => {
      try {
        const token = localStorage.getItem("token");
        const headers = { headers: { Authorization: `Bearer ${token}` } };
        const [prodRes, shadeRes] = await Promise.all([
          api.get("/items?limit=100", headers),
          api.get("/textiles/shade-card", headers),
        ]);
        setProducts(prodRes.data.data || []);
        setShades(shadeRes.data.data || []);
      } catch {
        toast.error("Failed to load master data");
      }
    };
    loadMasters();

    if (isEdit) {
      const fetchData = async () => {
        try {
          const token = localStorage.getItem("token");
          const res = await api.get(`/textiles/bom/${id}`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          setFormData(res.data.data);
        } catch {
          toast.error("Failed to load BOM");
        } finally {
          setFetching(false);
        }
      };
      fetchData();
    } else {
      setFetching(false);
    }
  }, [id, isEdit]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleCompChange = (e) => {
    const { name, value } = e.target;
    setCompInput((prev) => ({ ...prev, [name]: value }));
  };

  const addComponent = () => {
    if (!compInput.item || !compInput.quantity) {
      return toast.warn("Item and quantity required");
    }
    const newComp = {
      item: compInput.item,
      quantity: parseFloat(compInput.quantity) || 0,
      unit: compInput.unit || "",
      wasteFactor: parseFloat(compInput.wasteFactor) || 0,
      notes: compInput.notes || "",
    };
    setFormData((prev) => ({
      ...prev,
      components: [...prev.components, newComp],
    }));
    setCompInput({ item: "", quantity: 0, unit: "", wasteFactor: 0, notes: "" });
  };

  const removeComponent = (index) => {
    setFormData((prev) => ({
      ...prev,
      components: prev.components.filter((_, i) => i !== index),
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const token = localStorage.getItem("token");
      const headers = { headers: { Authorization: `Bearer ${token}` } };
      const method = isEdit ? "put" : "post";
      const url = isEdit ? `/textiles/bom/${id}` : "/textiles/bom";
      await api[method](url, formData, headers);
      toast.success(isEdit ? "BOM updated!" : "BOM created!");
      router.push("/admin/textiles/bom");
    } catch (err) {
      toast.error(err.response?.data?.message || "Operation failed");
    } finally {
      setLoading(false);
    }
  };

  if (fetching) return <div className="p-6 text-center">Loading...</div>;

  return (
    <div className="max-w-3xl mx-auto p-6 bg-white rounded-2xl shadow-sm border border-gray-100">
      <h1 className="text-2xl font-extrabold text-gray-900 mb-6">
        {isEdit ? "Edit Textile BOM" : "Create Textile BOM"}
      </h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">BOM Code *</label>
          <input name="bomCode" value={formData.bomCode} onChange={handleChange} required className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-400 outline-none" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Product</label>
          <select name="product" value={formData.product || ""} onChange={handleChange} className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-400 outline-none">
            <option value="">Select Product</option>
            {products.map((p) => (
              <option key={p._id} value={p._id}>{p.itemName}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Shade</label>
          <select name="shade" value={formData.shade || ""} onChange={handleChange} className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-400 outline-none">
            <option value="">Select Shade</option>
            {shades.map((s) => (
              <option key={s._id} value={s._id}>{s.name} ({s.code})</option>
            ))}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Waste %</label>
            <input type="number" step="0.1" name="wastePercent" value={formData.wastePercent || 0} onChange={handleChange} className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-400 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Batch / Lot</label>
            <input name="batchNo" value={formData.batchNo || ""} onChange={handleChange} className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-400 outline-none" />
          </div>
        </div>

        {/* Components */}
        <div>
          <label className="block text-sm font-medium text-gray-700">Components</label>
          <div className="space-y-2">
            {formData.components.map((comp, idx) => (
              <div key={idx} className="flex items-center gap-2 p-3 bg-gray-50 rounded-lg border border-gray-200">
                <span className="flex-1 font-medium">
                  {products.find(p => p._id === comp.item)?.itemName || comp.item}
                </span>
                <span className="text-sm text-gray-600">{comp.quantity} {comp.unit}</span>
                <span className="text-sm text-gray-600">Waste: {comp.wasteFactor}%</span>
                <button type="button" onClick={() => removeComponent(idx)} className="text-red-500 hover:text-red-700">
                  <FaTrash size={14} />
                </button>
              </div>
            ))}
          </div>
          <div className="grid grid-cols-5 gap-2 mt-2">
            <select name="item" value={compInput.item} onChange={handleCompChange} className="p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-400 outline-none">
              <option value="">Item</option>
              {products.map((p) => (
                <option key={p._id} value={p._id}>{p.itemName}</option>
              ))}
            </select>
            <input name="quantity" type="number" placeholder="Qty" value={compInput.quantity} onChange={handleCompChange} className="p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-400 outline-none" />
            <input name="unit" placeholder="Unit" value={compInput.unit} onChange={handleCompChange} className="p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-400 outline-none" />
            <input name="wasteFactor" type="number" placeholder="Waste %" value={compInput.wasteFactor} onChange={handleCompChange} className="p-2 border border-gray-200 rounded-lg focus:ring-2 focus:ring-indigo-400 outline-none" />
            <button type="button" onClick={addComponent} className="flex items-center justify-center gap-1 bg-indigo-500 text-white p-2 rounded-lg hover:bg-indigo-600 transition">
              <FaPlus size={14} /> Add
            </button>
          </div>
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700">Status</label>
          <select name="status" value={formData.status || "draft"} onChange={handleChange} className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-400 outline-none">
            <option value="draft">Draft</option>
            <option value="active">Active</option>
            <option value="archived">Archived</option>
          </select>
        </div>

        <div className="flex gap-4 pt-4">
          <button type="submit" disabled={loading} className="flex items-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition disabled:opacity-50">
            <FaSave size={14} /> {loading ? "Saving..." : "Save"}
          </button>
          <button type="button" onClick={() => router.back()} className="flex items-center gap-2 px-6 py-3 bg-gray-100 text-gray-700 rounded-xl font-bold hover:bg-gray-200 transition">
            <FaTimes size={14} /> Cancel
          </button>
        </div>
      </form>
    </div>
  );
}