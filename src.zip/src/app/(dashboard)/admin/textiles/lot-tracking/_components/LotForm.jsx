// app/admin/textiles/lot-tracking/_components/LotForm.jsx
"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import api from "@/lib/api";
import { toast } from "react-toastify";
import { FaSave, FaTimes } from "react-icons/fa";

export default function LotForm({ id }) {
  const router = useRouter();
  const isEdit = !!id;
  const [formData, setFormData] = useState({
    lotNumber: "",
    product: "",
    shade: "",
    quantity: 0,
    unit: "",
    supplier: "",
    purchaseOrder: "",
    receivedDate: "",
    qualityGrade: "",
    notes: "",
    status: "in-stock",
  });
  const [products, setProducts] = useState([]);
  const [shades, setShades] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(isEdit);

  useEffect(() => {
    // Load master data
    const loadMasters = async () => {
      try {
        const token = localStorage.getItem("token");
        const headers = { headers: { Authorization: `Bearer ${token}` } };
        const [prodRes, shadeRes, supRes] = await Promise.all([
          api.get("/items?limit=100", headers),
          api.get("/textiles/shade-card", headers),
          api.get("/suppliers?limit=100", headers),
        ]);
        setProducts(prodRes.data.data || []);
        setShades(shadeRes.data.data || []);
        setSuppliers(supRes.data.data || []);
      } catch {
        toast.error("Failed to load master data");
      }
    };
    loadMasters();

    if (isEdit) {
      const fetchData = async () => {
        try {
          const token = localStorage.getItem("token");
          const res = await api.get(`/textiles/lot-tracking/${id}`, {
            headers: { Authorization: `Bearer ${token}` },
          });
          const data = res.data.data;
          // Format date for input
          if (data.receivedDate) {
            data.receivedDate = new Date(data.receivedDate).toISOString().split("T")[0];
          }
          setFormData(data);
        } catch {
          toast.error("Failed to load lot");
        } finally {
          setFetching(false);
        }
      };
      fetchData();
    } else {
      setFetching(false);
    }
  }, [id, isEdit]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const token = localStorage.getItem("token");
      const headers = { headers: { Authorization: `Bearer ${token}` } };
      const method = isEdit ? "put" : "post";
      const url = isEdit ? `/textiles/lot-tracking/${id}` : "/textiles/lot-tracking";
      await api[method](url, formData, headers);
      toast.success(isEdit ? "Lot updated!" : "Lot created!");
      router.push("/admin/textiles/lot-tracking");
    } catch (err) {
      toast.error(err.response?.data?.message || "Operation failed");
    } finally {
      setLoading(false);
    }
  };

  if (fetching) return <div className="p-6 text-center">Loading...</div>;

  return (
    <div className="max-w-2xl mx-auto p-6 bg-white rounded-2xl shadow-sm border border-gray-100">
      <h1 className="text-2xl font-extrabold text-gray-900 mb-6">
        {isEdit ? "Edit Lot" : "Create Lot"}
      </h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700">Lot Number *</label>
          <input name="lotNumber" value={formData.lotNumber} onChange={handleChange} required className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 outline-none" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Product</label>
          <select name="product" value={formData.product || ""} onChange={handleChange} className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 outline-none">
            <option value="">Select Product</option>
            {products.map((p) => (
              <option key={p._id} value={p._id}>{p.itemName}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Shade</label>
          <select name="shade" value={formData.shade || ""} onChange={handleChange} className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 outline-none">
            <option value="">Select Shade</option>
            {shades.map((s) => (
              <option key={s._id} value={s._id}>{s.name} ({s.code})</option>
            ))}
          </select>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700">Quantity *</label>
            <input type="number" name="quantity" value={formData.quantity} onChange={handleChange} required className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Unit *</label>
            <input name="unit" value={formData.unit} onChange={handleChange} required className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 outline-none" />
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Supplier</label>
          <select name="supplier" value={formData.supplier || ""} onChange={handleChange} className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 outline-none">
            <option value="">Select Supplier</option>
            {suppliers.map((s) => (
              <option key={s._id} value={s._id}>{s.name}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Purchase Order</label>
          <input name="purchaseOrder" value={formData.purchaseOrder || ""} onChange={handleChange} className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 outline-none" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Received Date</label>
          <input type="date" name="receivedDate" value={formData.receivedDate || ""} onChange={handleChange} className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 outline-none" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Quality Grade</label>
          <input name="qualityGrade" value={formData.qualityGrade || ""} onChange={handleChange} className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 outline-none" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Notes</label>
          <textarea name="notes" value={formData.notes || ""} onChange={handleChange} rows={3} className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 outline-none" />
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700">Status</label>
          <select name="status" value={formData.status || "in-stock"} onChange={handleChange} className="w-full p-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 outline-none">
            <option value="in-stock">In Stock</option>
            <option value="used">Used</option>
            <option value="damaged">Damaged</option>
          </select>
        </div>
        <div className="flex gap-4 pt-4">
          <button type="submit" disabled={loading} className="flex items-center gap-2 px-6 py-3 bg-amber-600 text-white rounded-xl font-bold hover:bg-amber-700 transition disabled:opacity-50">
            <FaSave size={14} /> {loading ? "Saving..." : "Save"}
          </button>
          <button type="button" onClick={() => router.back()} className="flex items-center gap-2 px-6 py-3 bg-gray-100 text-gray-700 rounded-xl font-bold hover:bg-gray-200 transition">
            <FaTimes size={14} /> Cancel
          </button>
        </div>
      </form>
    </div>
  );
}